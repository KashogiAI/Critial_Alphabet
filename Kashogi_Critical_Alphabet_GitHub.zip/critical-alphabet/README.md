# The critical alphabet exponent for exact classical simulation of quantum measurements

**Author:** Kashogi  
**Research draft for independent review.** October 31, 2026. The manuscript is AI-assisted and has not been peer reviewed or independently verified.

The single manuscript contains the binary endpoint and its proof, the explicit cap protocol, its two-sided alphabet tail, the binary-to-general-measurement reduction, the finite-decoder obstruction above the endpoint, and the numerical evidence. The PDF carries this complete ZIP as an attachment. If a browser PDF viewer hides attachments, open the PDF in a desktop reader or use Poppler's pdfdetach.

The public release is at https://kashogi.com/research/critical-alphabet/ and the complete source and raw results are at https://kashogi.com/research/critical-alphabet/source.zip.

## Reproduce the checks

The reference run used 64-bit Linux, Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8. Use Python 3.12 for the pinned environment. Dependency installation needs access to a Python package index. The checks then run locally with no third-party services or input files.

From this directory:

    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install -r requirements-pinned.txt
    python verify.py

This verifies all file hashes, executes the analytic, POVM and regression checks, and reconstructs the reported totals, Born intervals and fixed-decoder lower bounds from the released records. Expected result: PASS. For a fresh CPU simulation on Linux:

    python verify.py --full

The full check writes a fresh panel to a temporary directory, verifies it and compares every cell against the reference, excluding timing. Exit status zero means success. The strict replay targets the reference library versions and CPU numerical environment. Other architectures or GPU random generators may produce different samples. To keep the generated raw results on disk, run:

    OPENBLAS_NUM_THREADS=1 python -m ququart_lab.campaign --backend numpy --core-only --out runs/new-cpu

A run directory must be fresh for an independent replay. The optional RTX campaign is available with bash run_gpu.sh --core-only (or bash run_gpu.sh --hours 8 for extended sampling). The manuscript reports CPU data only. The GPU launcher is specific to a supported NVIDIA RTX 5090 setup on Linux.

## Audit one claim

| Claim | Command | Expected check |
|---|---|---|
| Jacobi normalization | `python -c "from check_dimension import normalization_checks as f; f()"` | The normalized value at fidelity one equals 1. At d=5, n=2 the incorrect denominator gives 2. Both are computed exactly. |
| Positive mixing moments, Jacobi products, endpoint dyadic sum, high-degree quotient | `python check_dimension.py` | Rational checks, 80-digit decimal series, and comparison with the SciPy grid. Full expected printout in reference/analytic.log. |
| General-measurement decoder | `python check_povm_lift.py` | At each of s=1/256 and s=1/128, all 12 exact means match and the explicitly constructed faulty vector fails in 6 of 18 blocks. The stress panel checks 6,480 floating-point vectors. Expected JSON in reference/povm_checks.json. |
| CPU panel and saved witnesses | `python verify.py` | 93 cells, 6,943,070 cap anchors, 62,487,630 bit evaluations, 2,681,733,120 pairwise centre fidelities, and 3,145,728 packet trials. |
| Rerun all sampling | `python verify.py --full` | Published counts and saved centre digests reproduced with the reference setup. |

Do not run Python with -O or PYTHONOPTIMIZE set. The check drivers reject disabled assertions. The fidelity grid contains 110 entries, of which 109 are distinct: its two segments share 0.01.

## Contents

- main.tex is the complete source for the unified paper. Common LaTeX packages suffice; there is no external bibliography database or custom journal class.
- check_dimension.py contains all analytic companion routines, including normalization_checks. The denominator mutation is an executable exact assertion.
- check_povm_lift.py contains the exact and numerical fixtures for the reduction. Its binary responses are a test fixture. It does not implement the full quantum communication simulator.
- ququart_lab/, tests/, PLAN.md and run_gpu.sh contain the full experiment, optional exploratory modules, sampling plan, seeds, tolerances, fault controls and finite-core launcher.
- reference/cells/ contains all 93 JSON cells and 75 complex centre arrays. Each witness cell carries the hash of its array. Raw counts, panel-level output, validation logs, environment, source hashes and the figure are in reference/.
- SHA256SUMS covers manuscript source, result files, plotting code, launchers, citation metadata and instructions. For an independent integrity check, run sha256sum -c SHA256SUMS.
- CITATION.cff lists the author and manuscript title.

The nine bit tests inside one anchor share that anchor. The confidence intervals use the error allocation specified in PLAN.md. The endpoint claim concerns all inputs and all exact simulators; the mathematical argument is given in the paper.

## Build the manuscript

With TeX Live installed:

    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex

This builds the readable manuscript. To reproduce the PDF attachment, keep the downloaded ZIP in the parent folder and run:

    pdfattach main.pdf ../Kashogi_Source.zip Kashogi_Critical_Alphabet.pdf
    pdfdetach -list Kashogi_Critical_Alphabet.pdf

PDF timestamps and object serialization can differ between builds. The embedded ZIP can be extracted with pdfdetach -saveall Kashogi_Critical_Alphabet.pdf.

The consolidated edition includes reference/replay.log, a fresh reference-environment CPU replay that matched all 93 stored cells after ignoring elapsed times. The scripts use the same pseudorandom seeds as the original experiments.

## The two formulas in linear notation

Theorem 6, for d >= 5 and a = d - 2:

    M = essential supremum of |f|
    sup_{0<t<=1/2} norm_a(T_t f)^a <= C_d * M^(a-2) * norm_2(f)^2

Lemma 7, equations (8) and (9):

    B(n,a) = (n+a)! / (n! * a!)
    m_t(n) = JacobiP(n,a,0,2t-1) / B(n,a)
    m_0(n) = (-1)^n / B(n,a)
    q_t(n) = (m_t(n) - m_0(n)) / t

The manuscript derives the degree-two example in dimension five directly from three rational Haar moments. The 93 original sampling cells and their seeds are unchanged. The decoder fixture and its expected output have been revised.

## Revision 1.4

Theorem 6 and Lemma 13 credit the dimension-four spectral and zero-slope estimates to de Gois, Santos and Vieira (Appendices B.5–B.6). The bridge keeps each input cell's Haar mass when applying Cauchy–Schwarz. The proposed matching protocol and the higher-dimensional strong estimate have separate proofs. Lemma 15 displays both cap multipliers with their constants and isolates the finite-difference identity. Section 10 compares the construction with the earlier qutrit protocol.

The optional ququart_lab/protocol.py experiment uses a finite random list and a finite round limit. A random list may leave some caps uncovered. Its sampled message counts do not measure the full-tape alphabet. The original reference/manifest.json records the code hashes at the time of the original 93-cell run. SHA256SUMS identifies this edition.

In reference/povm_checks.json, exact and exact_theorem_scale give the twelve Born probabilities, the twelve computed means, and the actual correct and faulty probability totals for every positive-weight block. The fault removes only the far-outcome subtraction of R_j*S.
