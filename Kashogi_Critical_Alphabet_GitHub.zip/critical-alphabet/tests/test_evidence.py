"""Regression checks for errors with direct implications for the reported evidence."""
from pathlib import Path
import sys

import numpy as np
from scipy.stats import binomtest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from ququart_lab import cpn, evidence as E, protocol as P


def test_binomial_intervals():
    for n in (10,150000):
        for k in (0,1,n//5,n//2,n-1,n):
            got=E.interval(k,n,1e-4)
            ref=binomtest(k,n).proportion_ci(1-1e-4,method="exact")
            np.testing.assert_allclose(got,ref,atol=2e-10)
            assert got[0] <= k/n <= got[1]


def test_packets():
    from math import comb
    for total in (9,19):
        for size in range(1,total+1):
            for b in range(total):
                q=comb(total-1-b,size-1)/comb(total-1,size-1)
                np.testing.assert_allclose(P.safe_peer_probability(total,b,size), q, atol=1e-15)


def test_exhaustion():
    # Force no trial to encode; preserving the denominator must give zero, not NaN.
    a=P.Params(d=4,s=0.15,lam=1.0,H=10**12,rounds=1)
    r=P.run_point(a,[0.3],32,8,log=lambda *args: None)
    h=r["responses"][0]
    assert h["pairs"]==32 and h["failed_pairs"]==32 and h["grouped_freq"]==h["ungrouped_freq"]==0


def test_tagged_band_and_mutation():
    y=cpn.haar_rays(np,np.random.default_rng(121),1,4)
    w=E.witness_job(np,np.random.default_rng(9),y,.12,5000,.001)
    assert w["hits"]==w["trials"] and w["ensemble_prediction"]==1
    r=E.born_job(np,np.random.default_rng(64),4,65536,.0001,.06)
    assert r["responses"][0]["hits"]==0
    assert r["responses"][-1]["hits"]==r["accepted"] and r["mutant_detected"]
    assert E.parity(np)<2e-13


if __name__=="__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok",name)
