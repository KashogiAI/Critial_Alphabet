"""Fast regression tests (CPU, ~20 s):  python -m pytest tests/  or  python tests/test_core.py"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from ququart_lab import cpn, zonal as Z, scalelaw as S, endpoint as E, protocol as Pm


def test_zonal_orthonormality():
    x, w = np.polynomial.legendre.leggauss(200); t = 0.5 * (x + 1); w = 0.5 * w
    for d in (4, 5, 6):
        for l in range(5):
            assert abs(np.sum(w * Z.phi(l, t, d) ** 2 * (d - 1) * (1 - t) ** (d - 2)) * Z.dim_level(l, d) - 1) < 1e-10


def test_lemma_A1():
    sup, _ = Z.multiplier_sup(4, 200)
    assert 1.999 < sup < 2.0


def test_scale_law():
    assert abs(S.Q_numeric(0) - 1) < 1e-10 and abs(S.Q_numeric(-1) - 1.25) < 1e-10
    assert abs(S.nu_mass(0, 0.5, 400) - 1) < 1e-9
    assert all(abs(S.jacobi_cancellation(j)[0] / S.jacobi_cancellation(j)[1]) < 1e-12 for j in range(1, 15))
    assert abs(S.mixture(0.3) - 0.3) < 1e-6


def test_band_mean_vs_mc():
    rng = np.random.default_rng(0); d, s, t, tau = 4, 0.05, 0.08, 0.3
    x = cpn.haar_rays(np, rng, 1, d); y = cpn.rays_at_fidelity(np, rng, x, tau)
    Zt = cpn.fidelity_sphere_samples(np, rng, x, t, 200000)[0]
    mc = np.mean(cpn.fidelity(np, y, Zt)[0] <= s); ex = Z.band_Rt_scalar(tau, t, s, d)
    assert abs(mc - ex) < 4 * np.sqrt(ex * (1 - ex) / 200000) + 1e-3


def test_cap_response_endpoints():
    assert abs(Z.cap_response(0.0, 0.05, 5)) < 1e-9 and abs(Z.cap_response(1.0, 0.05, 5) - 1) < 1e-9


def test_endpoint_runs():
    rng = np.random.default_rng(0)
    cfg = E.Config(d=4, family="union", n_cap=100, n_out=50, m_cap=100, m_out=200, p_grid=[2.0, 3.0], t_over_s=[2.0, 4.0])
    rows = E.run_scale(cfg, 0.1, rng, np, log=lambda *a: None)
    assert len(rows) == 4 and all(np.isfinite(r["norm_p_pow_p"]) for r in rows)


def test_protocol_exact():
    P = Pm.Params(d=4, s=0.1, lam=4.0, rounds=96, seed=1)
    res = Pm.run_point(P, [0.1, 0.3], 3000, 2000, log=lambda *a: None)
    assert res["stats"]["pg_below_c"] == 0
    for r in res["responses"]:
        assert abs(r["grouped_z"]) < 4 and abs(r["ungrouped_z"]) < 4


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
