#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1
unset PYTHONOPTIMIZE
# Reuse the caller's Python if it is ready. Otherwise install into this lab's own venv.
PY="${PYTHON:-python3}"
if [[ -x .venv/bin/python ]]; then PY="$PWD/.venv/bin/python"; fi
if ! "$PY" -c 'import numpy, scipy, matplotlib, cupy' >/dev/null 2>&1; then
  if ! command -v nvidia-smi >/dev/null; then
    echo "nvidia-smi is unavailable. Check your NVIDIA driver before launching." >&2; exit 1
  fi
  driver_info=$(nvidia-smi)
  cuda=$(sed -nE 's/.*CUDA Version: ([0-9]+\.[0-9]+).*/\1/p' <<<"$driver_info" | head -1)
  if [[ -z "$cuda" ]]; then echo "Could not detect driver-supported CUDA version from nvidia-smi." >&2; exit 1; fi
  case "$cuda" in
    12.*) if (( ${cuda#12.} < 8 )); then echo "This RTX build needs CUDA 12.8+ support from the driver." >&2; exit 1; fi; wheel=cupy-cuda12x ;;
    13.*) wheel=cupy-cuda13x ;;
    *) echo "Unsupported driver CUDA family: $cuda" >&2; exit 1 ;;
  esac
  if [[ ! -x .venv/bin/python ]]; then
    "$PY" -m venv .venv || { echo "Install python3-venv on Linux Mint and rerun." >&2; exit 1; }
  fi
  PY="$PWD/.venv/bin/python"
  "$PY" -m pip install -r requirements.txt "${wheel}[ctk]>=14,<15"
fi
exec "$PY" -m ququart_lab.campaign --backend cupy "$@"
