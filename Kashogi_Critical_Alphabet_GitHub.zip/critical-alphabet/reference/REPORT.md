# CPU evidence report

**FINITE CHECKS PASSED**

93 of 93 prespecified core cells complete. 93 total cells, including replication. Backend numpy in double precision.

Accepted cap anchors: 6,943,070 from 62,914,560 proposals. Test bits evaluated: 62,487,630 (the fidelities share anchors). Endpoint pairwise centre fidelities: 2,681,733,120. Permutation trials: 3,145,728.

Largest absolute Born residual 0.00219489 in w0002-born-d7-n0 at t=0.5. Observed 97,638/196,137. Simultaneous interval [0.492764, 0.502846].

### Finest core scale per dimension

Bounds below use the smallest certificate across the completed core seeds at that scale. The quantity certified is the p-th power of the norm on the full space.

| d | Centres | s | p | Lower bound | Seeds complete |
|---:|---:|---:|---:|---:|---:|
| 4 | 512 | 0.000325521 | 3 | 0.87275 | 3 |
| 5 | 512 | 0.000244141 | 4 | 0.106409 | 3 |
| 6 | 512 | 0.000195313 | 5 | 0.0126192 | 3 |
| 7 | 512 | 0.00016276 | 6 | 0.00155111 | 3 |
| 8 | 512 | 0.000139509 | 7 | 0.000185654 | 3 |

### Interpretation

The sampled component is the cap mixture for pure preparations and one rank-one binary test. The packet panel isolates Bob's conditional correction. The saved decoders give finite lower confidence bounds for the fidelity difference quotient. The run neither implements the full all-input routing construction nor measures its used alphabet or the universal converse.

Use status.json for all flags and missing core cells. Each cell file contains the counts, parameters, interval and seed. PLAN.md specifies the decision rules. Every extension flag is retained even after the core finishes.
