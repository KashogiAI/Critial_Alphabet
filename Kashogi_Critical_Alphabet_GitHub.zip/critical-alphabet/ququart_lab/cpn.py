"""Geometry of complex projective space CP^{d-1} with the Fubini-Study / projector metric.

Conventions (match the manuscript):
    t(x, y) = |<x, y>|^2                      fidelity in [0, 1]
    d(x, y) = sqrt(1 - t)                     projector distance ||P_x - P_y||_op
    Haar density of fidelity to a fixed ray:  (d-1) (1-t)^{d-2} dt
    cap  C_s(x) = {z : t(x, z) > 1 - s}       mass s^{d-1}
    band B_s(y) = {z : t(y, z) <= s}          mass 1 - (1-s)^{d-1}

Array backend: every function takes `xp` (numpy or cupy) and a Generator from
`xp.random.default_rng`. Nothing here is NumPy-specific beyond that API.
"""
from __future__ import annotations

import numpy as np


# --------------------------------------------------------------------------- backend
def get_xp(backend: str = "numpy"):
    if backend == "cupy":
        import cupy as cp  # type: ignore
        return cp
    if backend == "numpy":
        return np
    raise ValueError(f"unknown backend {backend!r}; use 'numpy' or 'cupy'")


def to_np(a):
    """Bring an array to host NumPy regardless of backend."""
    try:
        import cupy as cp  # type: ignore
        if isinstance(a, cp.ndarray):
            return cp.asnumpy(a)
    except ImportError:
        pass
    return np.asarray(a)


# --------------------------------------------------------------------------- masses
def cap_mass(s: float, d: int) -> float:
    return float(s) ** (d - 1)


def band_mass(s: float, d: int) -> float:
    return 1.0 - (1.0 - float(s)) ** (d - 1)


def fidelity_density(t, d: int):
    """Haar density of the fidelity to a fixed ray, (d-1)(1-t)^{d-2}."""
    return (d - 1) * (1.0 - t) ** (d - 2)


# --------------------------------------------------------------------------- sampling
def uniform(xp, rng, size, dtype=None, lo: float = 0.0, hi: float = 1.0):
    """Uniform floats on [lo, hi) via Generator.random, which both NumPy and CuPy provide."""
    dtype = dtype or xp.float64
    u = rng.random(size=size, dtype=dtype)
    return u if (lo == 0.0 and hi == 1.0) else lo + (hi - lo) * u


def haar_rays(xp, rng, n: int, d: int, dtype=None):
    """n Haar-random unit vectors in C^d (rows). Complex dtype defaults to complex128."""
    dtype = dtype or xp.complex128
    real_dtype = xp.float32 if dtype == xp.complex64 else xp.float64
    g = rng.standard_normal((n, d), dtype=real_dtype) + 1j * rng.standard_normal((n, d), dtype=real_dtype)
    g = g.astype(dtype)
    g /= xp.linalg.norm(g, axis=1, keepdims=True)
    return g


def haar_unitary(xp, rng, d: int, dtype=None):
    """Haar-random d x d unitary via QR with phase correction."""
    dtype = dtype or xp.complex128
    g = (rng.standard_normal((d, d)) + 1j * rng.standard_normal((d, d))).astype(dtype)
    q, r = xp.linalg.qr(g)
    ph = xp.diag(r)
    ph = ph / xp.abs(ph)
    return q * ph[None, :]


def fidelity(xp, X, Z):
    """Pairwise fidelities |<x_i, z_j>|^2, shape (len(X), len(Z))."""
    return xp.abs(X.conj() @ Z.T) ** 2


def fidelity_rows(xp, X, Y):
    """Row-wise fidelities |<x_i, y_i>|^2 for equally shaped X, Y."""
    return xp.abs(xp.sum(X.conj() * Y, axis=-1)) ** 2


def _orthonormal_perp(xp, rng, X, m: int):
    """For each row x of X (N,d) return m unit vectors orthogonal to x: shape (N,m,d)."""
    N, d = X.shape
    dtype = X.dtype
    real_dtype = xp.float32 if dtype == xp.complex64 else xp.float64
    W = rng.standard_normal((N, m, d), dtype=real_dtype) + 1j * rng.standard_normal((N, m, d), dtype=real_dtype)
    W = W.astype(dtype)
    # project out x
    coef = xp.sum(X.conj()[:, None, :] * W, axis=-1, keepdims=True)
    W = W - coef * X[:, None, :]
    W /= xp.linalg.norm(W, axis=-1, keepdims=True)
    return W


def fidelity_sphere_samples(xp, rng, X, t: float, m: int):
    """For each x in X, m Haar-uniform points on {z : t(x,z) = t}: shape (N,m,d).

    z = e^{i a} sqrt(t) x + sqrt(1-t) w, w uniform unit in x^perp, a uniform phase.
    For t = 0 this is the orthogonal complement CP^{d-2} of x.
    """
    N, d = X.shape
    W = _orthonormal_perp(xp, rng, X, m)
    if t == 0.0:
        return W
    real_dtype = xp.float32 if X.dtype == xp.complex64 else xp.float64
    a = uniform(xp, rng, (N, m, 1), real_dtype, 0.0, 2 * np.pi)
    ph = xp.exp(1j * a).astype(X.dtype)
    return ph * np.sqrt(t) * X[:, None, :] + np.sqrt(1.0 - t) * W


def coupled_sphere_samples(xp, rng, X, t: float, m: int):
    """Common-random-number pair (Z_t, Z_0) sharing w and the phase.

    Used for the difference quotient (R_t f - R_0 f)/t: f(Z_t) - f(Z_0) is nonzero
    only when the shift crosses a level set of f, which removes almost all of the
    Monte Carlo variance.
    """
    W = _orthonormal_perp(xp, rng, X, m)
    real_dtype = xp.float32 if X.dtype == xp.complex64 else xp.float64
    a = uniform(xp, rng, (X.shape[0], m, 1), real_dtype, 0.0, 2 * np.pi)
    ph = xp.exp(1j * a).astype(X.dtype)
    Zt = ph * np.sqrt(t) * X[:, None, :] + np.sqrt(1.0 - t) * W
    return Zt, W


def rays_at_fidelity(xp, rng, X, t: float):
    """One partner y per row of X with t(x, y) = t exactly: shape (N, d)."""
    return fidelity_sphere_samples(xp, rng, X, t, 1)[:, 0, :]


def cap_samples(xp, rng, centres, s: float, counts):
    """Uniform samples in the caps C_s(centre): for centre i draw counts[i] points.

    The fidelity u to the centre has density (d-1)(1-u)^{d-2} on (1-s, 1], which is
    inverted exactly: 1-u = s * V^{1/(d-1)} with V uniform.
    Returns (points (sum counts, d), centre_index (sum counts,)).
    """
    counts = np.asarray(to_np(counts), dtype=int)
    idx = np.repeat(np.arange(len(counts)), counts)
    idx_x = xp.asarray(idx)
    C = centres[idx_x]
    n_tot = len(idx)
    d = centres.shape[1]
    real_dtype = xp.float32 if centres.dtype == xp.complex64 else xp.float64
    V = uniform(xp, rng, (n_tot, 1), real_dtype)
    one_minus_u = (s * V ** (1.0 / (d - 1))).astype(real_dtype)
    u = 1.0 - one_minus_u
    W = _orthonormal_perp(xp, rng, C, 1)[:, 0, :]
    a = uniform(xp, rng, (n_tot, 1), real_dtype, 0.0, 2 * np.pi)
    ph = xp.exp(1j * a).astype(centres.dtype)
    X = ph * xp.sqrt(u) * C + xp.sqrt(one_minus_u) * W
    return X, idx_x
