"""Zonal harmonic analysis on CP^{d-1} and exact spherical means of a band.

Spectral side
-------------
The zonal function of harmonic level l on CP^{d-1} is
    phi_l(t) = P_l^{(d-2,0)}(2t-1) / C(l+d-2, l),     phi_l(1) = 1,
orthogonal for the fidelity weight (d-1)(1-t)^{d-2} dt, with
    integral phi_l^2 dmu = 1 / dim_l,   dim_l = (2l+d-1)/(d-1) * C(l+d-2,l)^2.
The spherical mean at fidelity t acts on level l by multiplication by phi_l(t),
so the difference quotient T_t = (R_t - R_0)/t has multiplier
    m_l(t) = (phi_l(t) - phi_l(0)) / t.
Lemma A.1 of the manuscript: for d = 4, sup_{l, 0<t<=1/2} |m_l(t)| = 2.

Direct side (no truncation, no Jacobi)
-------------------------------------
For the band b_s(z) = 1{ t(y,z) <= s } the spherical mean at a point x with
tau = t(x,y) is a one-dimensional integral. Writing z on the fidelity-t sphere
around x as z = e^{ia} sqrt(t) x + sqrt(1-t) w, the overlap with y is
    |<y,z>|^2 = | sqrt(tau t) + sqrt((1-tau)(1-t) rho) e^{i theta} |^2,
with theta uniform and rho = |<x_perp, w>|^2 ~ Beta(1, d-2). Hence
    R_t b_s(tau) = E_rho [ P_theta( A^2 + B^2 + 2AB cos theta <= s ) ].
This is `band_Rt`. The same kernel gives the cap response
    K_s(tau) = 1 - E_{u ~ cap}[ R_u b_s(tau) ],
with u the fidelity of a uniform cap anchor to its centre (`cap_response`).
"""
from __future__ import annotations

from functools import lru_cache
from math import comb

import numpy as np
from scipy.special import eval_jacobi

# --------------------------------------------------------------------------- spectral
def C(l: int, d: int) -> int:
    return comb(l + d - 2, l)


def phi(l: int, t, d: int):
    return eval_jacobi(l, d - 2, 0, 2.0 * np.asarray(t, dtype=float) - 1.0) / C(l, d)


def dim_level(l: int, d: int) -> int:
    num = (2 * l + d - 1) * C(l, d) ** 2
    assert num % (d - 1) == 0
    return num // (d - 1)


def phi0(l: int, d: int) -> float:
    return (-1) ** l / C(l, d)


def phi_prime0(l: int, d: int) -> float:
    """phi_l'(0) = -l(l+d-1) phi_l(0)  (Rodrigues)."""
    return -l * (l + d - 1) * phi0(l, d)


def multiplier(l: int, t, d: int):
    t = np.asarray(t, dtype=float)
    return (phi(l, t, d) - phi0(l, d)) / t


def multiplier_sup(d: int, lmax: int, tgrid=None):
    """sup over l <= lmax and t in tgrid U {0+} of |m_l(t)|; returns (sup, argl, argt)."""
    if tgrid is None:
        tgrid = np.concatenate([np.geomspace(1e-7, 0.5, 400)])
    best, arg = -1.0, (None, None)
    for l in range(1, lmax + 1):
        vals = np.abs(multiplier(l, tgrid, d))
        slope0 = abs(phi_prime0(l, d))
        i = int(np.argmax(vals))
        if vals[i] > best:
            best, arg = float(vals[i]), (l, float(tgrid[i]))
        if slope0 > best:
            best, arg = float(slope0), (l, 0.0)
    return best, arg


# --------------------------------------------------------------------------- quadrature helpers
@lru_cache(maxsize=None)
def _gl(n: int):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * (x + 1.0), 0.5 * w  # on [0,1]


def _smooth_segment_nodes(a: float, b: float, n: int):
    """Nodes/weights on [a,b] with the substitution x = a + (b-a)(1-cos(pi xi))/2.

    The substitution turns endpoint sqrt singularities (arccos at c = +-1) into
    smooth integrands, so Gauss-Legendre in xi converges geometrically.
    """
    xi, wxi = _gl(n)
    x = a + (b - a) * 0.5 * (1.0 - np.cos(np.pi * xi))
    w = wxi * (b - a) * 0.5 * np.pi * np.sin(np.pi * xi)
    return x, w


# --------------------------------------------------------------------------- band means
def band_R0(tau, s: float, d: int):
    """R_0 b_s(tau) = P( (1-tau) rho <= s ) with rho ~ Beta(1, d-2)."""
    tau = np.asarray(tau, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(1.0 - tau > 0, np.minimum(1.0, s / np.maximum(1.0 - tau, 1e-300)), 1.0)
    return 1.0 - (1.0 - r) ** (d - 2)


def _p_theta(A: float, B, s: float):
    """P_theta( A^2 + B^2 + 2 A B cos theta <= s ), B array."""
    B = np.asarray(B, dtype=float)
    out = np.empty_like(B)
    AB = A * B
    small = AB <= 1e-300
    out[small] = (A * A + B[small] ** 2 <= s).astype(float)
    big = ~small
    c = (s - A * A - B[big] ** 2) / (2.0 * AB[big])
    cc = np.clip(c, -1.0, 1.0)
    out[big] = 1.0 - np.arccos(cc) / np.pi
    return out


def band_Rt_scalar(tau: float, t: float, s: float, d: int, n: int = 64) -> float:
    """R_t b_s at a point with fidelity tau to the band centre (d >= 3)."""
    if d < 3:
        raise ValueError("d >= 3 required")
    if t == 0.0:
        return float(band_R0(tau, s, d))
    scale = (1.0 - tau) * (1.0 - t)
    A = np.sqrt(tau * t)
    if scale <= 0.0:
        return float(A * A <= s)
    rs = np.sqrt(s)
    # breakpoints in rho where cos theta threshold hits +-1
    bps = []
    for Bb in (rs - A, A + rs, A - rs):
        if Bb > 0:
            rho_b = Bb * Bb / scale
            if 0.0 < rho_b < 1.0:
                bps.append(rho_b)
    edges = [0.0] + sorted(set(bps)) + [1.0]
    total = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        if b - a <= 0:
            continue
        rho, w = _smooth_segment_nodes(a, b, n)
        pdf = (d - 2) * (1.0 - rho) ** (d - 3)
        B = np.sqrt(scale * rho)
        total += float(np.sum(w * pdf * _p_theta(A, B, s)))
    return total


def band_Rt(tau, t: float, s: float, d: int, n: int = 64):
    tau = np.atleast_1d(np.asarray(tau, dtype=float))
    return np.array([band_Rt_scalar(float(x), t, s, d, n) for x in tau])


def Tt_band(tau, t: float, s: float, d: int, n: int = 64):
    """Difference quotient (R_t - R_0) b_s / t at fidelity tau."""
    return (band_Rt(tau, t, s, d, n) - band_R0(tau, s, d)) / t


def _tau_segments(s: float, t: float):
    pts = {0.0, 1.0, s, 4.0 * s, t, 4.0 * t, 1.0 - s, 1.0 - 4.0 * s * (1.0 - s), 1.0 - t}
    pts = sorted(p for p in pts if 0.0 <= p <= 1.0)
    return list(zip(pts[:-1], pts[1:]))


def lp_norms_band(t: float, s: float, d: int, p_list, n_tau: int = 48, n_rho: int = 48):
    """{p: ||T_t b_s||_p^p} on CP^{d-1} by composite quadrature over tau (exact up to quadrature)."""
    taus, ws, vals = [], [], []
    for a, b in _tau_segments(s, t):
        if b - a <= 0:
            continue
        tau, w = _smooth_segment_nodes(a, b, n_tau)
        taus.append(tau); ws.append(w * (d - 1) * (1.0 - tau) ** (d - 2))
        vals.append(Tt_band(tau, t, s, d, n_rho))
    w = np.concatenate(ws); v = np.abs(np.concatenate(vals))
    return {float(p): float(np.sum(w * v ** p)) for p in p_list}


def lp_norm_band(t: float, s: float, d: int, p: float, n_tau: int = 48, n_rho: int = 48):
    return lp_norms_band(t, s, d, [p], n_tau, n_rho)[float(p)] ** (1.0 / p)


# --------------------------------------------------------------------------- cap response
def cap_response(tau: float, s: float, d: int, n_u: int = 48, n_rho: int = 48) -> float:
    """K_s(tau): acceptance when the anchor is uniform in C_s(x), Bob accepts t(y,anchor) > s."""
    # 1-u = s v, v in (0,1), weight (d-1) v^{d-2}
    total = 0.0
    # breakpoints in v are messy; use two smoothed segments
    for a, b in ((0.0, 0.5), (0.5, 1.0)):
        v, w = _smooth_segment_nodes(a, b, n_u)
        for vi, wi in zip(v, w):
            u = 1.0 - s * vi
            total += wi * (d - 1) * vi ** (d - 2) * band_Rt_scalar(tau, u, s, d, n_rho)
    return 1.0 - total
