"""Experiment 1: the L^infty -> L^p endpoint exponent of T_t = (R_t - R_0)/t on CP^{d-1}.

Conjecture (the general-d obstruction): sup_{t} ||T_t f||_p / ||f||_inf is bounded
over all decoders f iff p <= d-2.

What is measured
----------------
For a family of decoders f_s with ||f_s||_inf = 1 we compute
    N_p(s) = sup_t ||T_t f_s||_p^p
on a grid of scales s and fit the exponent  e(p) = d log N_p / d log(1/s).
Boundedness means e(p) <= 0; divergence means e(p) > 0.

Families (all indicator functions of unions of fidelity bands {t(y_j, .) <= s}):
    band        one band.                 Prediction: e(p) = max(0, p - (d-1)).
    union       n = kappa s^-1/(d-1) bands with well-separated centres, the
                harmonic-analytic shadow of the grouping trick.
                                          Prediction: e(p) = max(0, p - (d-2)).
    gamma=G     n = kappa s^-G/(d-1) bands; G > 1 saturates (bands cover X),
                G < 1 under-uses the budget. The exponent should be maximised at G = 1.

Why the union family: for x in the cap of band j, the whole fidelity-t sphere of x
leaves the band once t > 4s(1-s), so T_t f(x) ~ -(1 - mass of the other bands)/t,
of size 1/s on a set of measure n s^{d-1}; the other n-1 bands contribute O(1) in
total because the Beta(1,d-2) density of the perpendicular overlap is flat at 0.
Hence N_p ~ s^{d-1-p} (band) and s^{d-2-p} (union), and the number of bands cannot
exceed order 1/s because each band carries Haar mass (d-1)s regardless of d.

Estimator
---------
Stratified Monte Carlo: x is sampled separately inside the caps (where |T| is large)
and outside. T_t f(x) is estimated with common random numbers for the fidelity-t and
fidelity-0 spheres, so only samples whose shifted copy crosses a band boundary
contribute variance. For the single band the result is cross-checked against the
exact one-dimensional integral in `zonal.lp_norm_band`.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import time
from dataclasses import dataclass, field, asdict

import numpy as np

from . import cpn
from . import zonal as Z


# --------------------------------------------------------------------------- decoders
class BandUnion:
    """f(z) = 1 if min_j t(y_j, z) <= s else 0."""

    def __init__(self, xp, Y, s: float):
        self.xp, self.Y, self.s = xp, Y, float(s)

    def __call__(self, Zflat):
        fid = cpn.fidelity(self.xp, Zflat, self.Y)
        return (fid.min(axis=1) <= self.s)

    def multiplicity(self, X):
        """number of caps C_s(y_j) containing each x."""
        return self.multiplicity_radius(X, self.s)

    def multiplicity_radius(self, X, radius: float):
        fid = cpn.fidelity(self.xp, X, self.Y)
        return (fid > 1.0 - radius).sum(axis=1)


def n_bands(family: str, s: float, d: int, kappa: float) -> tuple[int, float]:
    """(number of bands, effective scale). For gamma = 1 the scale is adjusted so that
    n = kappa / ((d-1) s) holds exactly, which removes integer-rounding noise from the fits."""
    if family == "band":
        return 1, s
    if family == "union":
        gamma = 1.0
    elif family.startswith("gamma="):
        gamma = float(family.split("=", 1)[1])
    else:
        raise ValueError(family)
    n = max(1, int(round(kappa * s ** (-gamma) / (d - 1))))
    s_eff = (kappa / ((d - 1) * n)) ** (1.0 / gamma)
    return n, s_eff


# --------------------------------------------------------------------------- core estimator
MAX_ELEMS = 40_000_000     # fidelity-matrix entries per chunk (rows * M * n_bands)
MAX_SAMPLES = 1_000_000    # sphere samples per chunk (rows * M); each is a d-vector


def difference_quotient(xp, rng, X, f, t: float, M: int, max_elems: int = None, max_samples: int = None):
    """Monte Carlo estimate of T_t f(x) for each row of X, coupled sampling.

    Returns (estimate, per-x standard error). Work is chunked so that
    chunk_rows * M * n_bands <= max_elems and chunk_rows * M <= max_samples.
    """
    max_elems = max_elems or MAX_ELEMS
    max_samples = max_samples or MAX_SAMPLES
    N, d = X.shape
    n_b = f.Y.shape[0]
    rows = min(int(max_elems // max(1, M * n_b)), int(max_samples // M))
    if rows < 1 or M > max_samples:
        # fall back to splitting the M samples of a single row into pieces
        return _difference_quotient_split_M(xp, rng, X, f, t, M, min(max_samples, max_elems//n_b))
    est = np.empty(N)
    se = np.empty(N)
    for i0 in range(0, N, rows):
        Xc = X[i0:i0 + rows]
        nc = Xc.shape[0]
        Zt, Z0 = cpn.coupled_sphere_samples(xp, rng, Xc, t, M)
        ft = f(Zt.reshape(-1, d)).reshape(nc, M).astype(xp.float64)
        f0 = f(Z0.reshape(-1, d)).reshape(nc, M).astype(xp.float64)
        diff = ft - f0
        m = diff.mean(axis=1) / t
        v = diff.var(axis=1) / (M * t * t)
        est[i0:i0 + nc] = cpn.to_np(m)
        se[i0:i0 + nc] = np.sqrt(cpn.to_np(v))
    return est, se


def _difference_quotient_split_M(xp, rng, X, f, t, M, max_samples):
    """Same estimator when a single row's M samples exceed the chunk budget."""
    N, d = X.shape
    est = np.empty(N); se = np.empty(N)
    piece = max(1, int(max_samples))
    for i in range(N):
        s1 = 0.0; s2 = 0.0; cnt = 0
        while cnt < M:
            m = min(piece, M - cnt)
            Zt, Z0 = cpn.coupled_sphere_samples(xp, rng, X[i:i + 1], t, m)
            diff = (f(Zt.reshape(-1, d)).astype(xp.float64) - f(Z0.reshape(-1, d)).astype(xp.float64))
            s1 += float(diff.sum()); s2 += float((diff * diff).sum()); cnt += m
        mean = s1 / M
        var = max(s2 / M - mean * mean, 0.0)
        est[i] = mean / t; se[i] = np.sqrt(var / M) / t
    return est, se


@dataclass
class Config:
    d: int = 4
    family: str = "union"
    kappa: float = 0.5
    s_grid: list = field(default_factory=lambda: [0.2, 0.1, 0.05, 0.025])
    t_over_s: list = field(default_factory=lambda: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0])
    p_grid: list = field(default_factory=lambda: [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0])
    n_cap: int = 2000          # x samples inside the caps
    n_out: int = 1000          # x samples outside the caps
    m_cap: int = 1000          # fidelity-sphere samples per cap point
    m_out: int = 4000          # per outside point
    seed: int = 0
    backend: str = "numpy"
    dtype: str = "complex64"


COLLAR_MARGIN = 1.5  # collar outer radius = COLLAR_MARGIN * (sqrt(t)+sqrt(s))^2


def _stratum_collar(xp, rng, f, s: float, r2: float, n_pts: int):
    """Importance-sample the collar {s <= 1 - max_j t(x,y_j) < r2} around the band centres.

    Proposal: pick a centre uniformly, draw the radial coordinate y = 1-u log-uniformly on
    [s, r2] (density psi(y) = 1/(y ln(r2/s))), then a uniform point on that fidelity sphere.
    Under Haar the radial coordinate has density (d-1) y^{d-2}, so the importance weight
    for E_mu[g 1_collar] ~= mean(weight * g) is
        weight(x) = n / sum_{j : s <= y_j(x) < r2} psi(y_j) / ((d-1) y_j^{d-2}),
    and points inside any inner cap (y_k < s for some k) get weight 0 (they belong to A).
    """
    n, d = f.Y.shape
    dtype = f.Y.dtype
    real_dtype = xp.float32 if dtype == xp.complex64 else xp.float64
    idx = rng.integers(n, size=n_pts)
    C = f.Y[idx]
    L = np.log(r2 / s)
    V = cpn.uniform(xp, rng, (len(idx), 1), real_dtype)
    y = (s * xp.exp(L * V)).astype(real_dtype)              # 1 - u
    W = cpn._orthonormal_perp(xp, rng, C, 1)[:, 0, :]
    a = cpn.uniform(xp, rng, (len(idx), 1), real_dtype, 0.0, 2 * np.pi)
    X = xp.exp(1j * a).astype(dtype) * xp.sqrt(1.0 - y) * C + xp.sqrt(y) * W
    yj = 1.0 - cpn.fidelity(xp, X, f.Y)                     # radial coordinates to every centre
    in_collar = (yj >= s) & (yj < r2)
    inner = (yj < s).any(axis=1)
    psi_over_haar = xp.where(in_collar, 1.0 / (xp.maximum(yj, 1e-300) * L) / ((d - 1) * xp.maximum(yj, 1e-300) ** (d - 2)), 0.0)
    denom = psi_over_haar.sum(axis=1)
    w = xp.where(inner | (denom <= 0), 0.0, n / xp.maximum(denom, 1e-300))
    return X, cpn.to_np(w).astype(float)


def _stratum_caps(xp, rng, f, radius: float, n_pts: int, exclude_radius: float | None):
    """Sample the union of caps of the given radius with the cap-sampling trick.

    Returns (X, weight) with weight = radius^{d-1} * n / mult(x) so that
    E_mu[g 1_stratum] ~= mean(weight * g). Points inside the excluded (smaller) caps
    are dropped by giving them weight 0.
    """
    n = f.Y.shape[0]
    counts = np.bincount(cpn.to_np(rng.integers(n, size=n_pts)), minlength=n)
    X, _ = cpn.cap_samples(xp, rng, f.Y, radius, counts)
    fid = cpn.fidelity(xp, X, f.Y)
    mult = cpn.to_np((fid > 1.0 - radius).sum(axis=1)).astype(float)
    assert np.all(mult >= 1)
    w = n * radius ** (f.Y.shape[1] - 1) / mult
    if exclude_radius is not None:
        inside = cpn.to_np((fid > 1.0 - exclude_radius).any(axis=1))
        w = np.where(inside, 0.0, w)
    return X, w


def _stratum_far(xp, rng, f, radius: float, n_pts: int, dtype):
    """One fixed Haar batch; the surviving fraction weights the far contribution."""
    X = cpn.haar_rays(xp, rng, n_pts, f.Y.shape[1], dtype)
    keep = f.multiplicity_radius(X, radius) == 0
    count = int(keep.sum())
    # A zero-mass estimate needs no conditional samples. A dummy row with
    # weight zero keeps the moment calculation well-defined.
    return (X[keep], count / n_pts) if count else (X[:1], 0.0)


def run_scale(cfg: Config, s_req: float, rng, xp, log=print):
    d = cfg.d
    dtype = getattr(xp, cfg.dtype)
    n, s = n_bands(cfg.family, s_req, d, cfg.kappa)
    Y = cpn.haar_rays(xp, rng, n, d, dtype)
    f = BandUnion(xp, Y, s)
    other_mass = 1.0 - (1.0 - cpn.band_mass(s, d)) ** (n - 1)  # mass of the other bands, if independent

    # stratum A: the caps of radius s (uniform sampling; |T| is nearly constant there)
    XA, wA = _stratum_caps(xp, rng, f, s, cfg.n_cap, None)
    mu_A = float(np.mean(wA))
    m_far = int(cfg.m_out * max(1.0, 0.1 / s))

    rows = []
    for r in cfg.t_over_s:
        t = r * s
        if t > 0.5:
            continue
        # stratum B: collar out to the radius where the fidelity-t sphere stops meeting the band
        r2 = min(1.0, COLLAR_MARGIN * (np.sqrt(t) + np.sqrt(s)) ** 2)
        if r2 < 1.0:
            XB, wB = _stratum_collar(xp, rng, f, s, r2, cfg.n_cap)
            XC, mu_C = _stratum_far(xp, rng, f, r2, cfg.n_out, dtype)
        else:
            XB, wB = None, None
            XC, mu_C = _stratum_far(xp, rng, f, s, cfg.n_out, dtype)
        mu_B = float(np.mean(wB)) if wB is not None else 0.0
        TA, seA = difference_quotient(xp, rng, XA, f, t, cfg.m_cap)
        TB, seB = (difference_quotient(xp, rng, XB, f, t, cfg.m_cap) if XB is not None else (np.zeros(1), np.zeros(1)))
        TC, seC = difference_quotient(xp, rng, XC, f, t, m_far)
        exact = Z.lp_norms_band(t, s, d, cfg.p_grid) if cfg.family == "band" else None
        for p in cfg.p_grid:
            gA = wA * np.abs(TA) ** p
            gB = wB * np.abs(TB) ** p if wB is not None else np.zeros(1)
            gC = mu_C * np.abs(TC) ** p
            parts = [float(g.mean()) for g in (gA, gB, gC)]
            ses = [float(g.std() / np.sqrt(len(g))) for g in (gA, gB, gC)]
            # inner-noise diagnostic for p = 2: E[est^2] - E[se^2] is unbiased for E[T^2]
            debias2 = (mu_C * float(np.mean(TC ** 2 - seC ** 2))) if p == 2.0 else float("nan")
            row = {
                "d": d, "family": cfg.family, "s": s, "s_requested": s_req, "n_bands": n, "t": t, "t_over_s": r, "p": p,
                "norm_p_pow_p": sum(parts), "cap_part": parts[0], "collar_part": parts[1], "far_part": parts[2],
                "se": float(np.sqrt(sum(x * x for x in ses))), "mu_caps": mu_A, "mu_collar": mu_B, "mu_far": mu_C,
                "far_part_p2_debiased": debias2,
                "mean_abs_T_cap": float(np.mean(np.abs(TA))), "mean_abs_T_far": float(np.mean(np.abs(TC))),
                "inner_se_cap": float(np.median(seA)), "inner_se_far": float(np.median(seC)),
                "m_far": m_far, "other_band_mass": other_mass,
                "exact_band": exact[float(p)] if exact else float("nan"),
            }
            rows.append(row)
        log(f"  s={s:.4g} n={n} t/s={r:g}: mean|T| caps={np.mean(np.abs(TA)):.4g} "
            f"(1/t={1/t:.4g}, (1-m_other)/t={(1-other_mass)/t:.4g}) far={np.mean(np.abs(TC)):.3g}±{np.median(seC):.2g}; "
            f"mu A/B/C={mu_A:.2e}/{mu_B:.2e}/{mu_C:.3f}")
    return rows


def fit_exponents(rows):
    """For each (family, d, p): slope of log max_t N vs log(1/s). Returns list of dicts."""
    import collections
    best = collections.defaultdict(dict)  # (family,d,p) -> s -> max over t
    for r in rows:
        key = (r["family"], r["d"], r["p"])
        val = r["exact_band"] if r["family"] == "band" else r["norm_p_pow_p"]
        best[key][r["s"]] = max(best[key].get(r["s"], 0.0), val)
    out = []
    for (fam, d, p), by_s in best.items():
        s = np.array(sorted(by_s))
        if len(s) < 2:
            continue
        y = np.log(np.array([by_s[v] for v in s]))
        x = np.log(1.0 / s)
        A = np.vstack([x, np.ones_like(x)]).T
        slope, _ = np.linalg.lstsq(A, y, rcond=None)[0]
        # local slope between the two smallest scales (closest to the asymptotics)
        local = (y[0] - y[1]) / (x[0] - x[1])
        pred = max(0.0, p - (d - 1)) if fam == "band" else max(0.0, p - (d - 2))
        out.append({"family": fam, "d": d, "p": p, "slope_global": float(slope), "slope_smallest_scales": float(local),
                    "predicted": pred})
    return sorted(out, key=lambda r: (r["family"], r["d"], r["p"]))


def crosscheck_band(cfg: Config, rows, log=print):
    """For the single band compare MC norms with the exact 1-D integral."""
    if cfg.family != "band":
        return []
    out = []
    for r in rows:
        exact = r["exact_band"]
        out.append({"s": r["s"], "t": r["t"], "p": r["p"], "mc": r["norm_p_pow_p"], "mc_se": r["se"], "exact": exact,
                    "rel_err": (r["norm_p_pow_p"] - exact) / exact, "z": (r["norm_p_pow_p"] - exact) / max(r["se"], 1e-300)})
    worst = max(abs(o["rel_err"]) for o in out) if out else float("nan")
    worst_z = max(abs(o["z"]) for o in out) if out else float("nan")
    log(f"  single-band MC vs exact 1-D integral: worst rel. err {worst:.2%}, worst |z| {worst_z:.1f} over {len(out)} (s,t,p) cases")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--d", type=int, nargs="+", default=[4])
    ap.add_argument("--family", type=str, nargs="+", default=["band", "union"])
    ap.add_argument("--s", type=float, nargs="+", default=None)
    ap.add_argument("--p", type=float, nargs="+", default=None)
    ap.add_argument("--kappa", type=float, default=0.5)
    ap.add_argument("--n-cap", type=int, default=2000)
    ap.add_argument("--n-out", type=int, default=1000)
    ap.add_argument("--m-cap", type=int, default=1000)
    ap.add_argument("--m-out", type=int, default=4000)
    ap.add_argument("--backend", default="numpy", choices=["numpy", "cupy"])
    ap.add_argument("--dtype", default="complex64", choices=["complex64", "complex128"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="out/endpoint")
    ap.add_argument("--no-plot", action="store_true")
    a = ap.parse_args(argv)

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    xp = cpn.get_xp(a.backend)
    all_rows, all_fits, all_xc = [], [], []
    t0 = time.time()
    for d in a.d:
        for fam in a.family:
            cfg = Config(d=d, family=fam, kappa=a.kappa, n_cap=a.n_cap, n_out=a.n_out, m_cap=a.m_cap, m_out=a.m_out,
                         seed=a.seed, backend=a.backend, dtype=a.dtype)
            if a.s:
                cfg.s_grid = a.s
            if a.p:
                cfg.p_grid = a.p
            rng = xp.random.default_rng(a.seed)
            print(f"== d={d} family={fam} ==")
            rows = []
            for s in cfg.s_grid:
                rows += run_scale(cfg, s, rng, xp)
            fits = fit_exponents(rows)
            for ft in fits:
                print(f"  p={ft['p']:<4g} slope(global)={ft['slope_global']:+.3f} slope(smallest s)={ft['slope_smallest_scales']:+.3f} "
                      f"predicted={ft['predicted']:+.3f}")
            all_xc += crosscheck_band(cfg, rows)
            all_rows += rows
            all_fits += fits
    print(f"total time {time.time()-t0:.1f}s")

    with open(a.out + "_rows.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(all_rows[0].keys()))
        w.writeheader(); w.writerows(all_rows)
    with open(a.out + "_fits.json", "w") as fh:
        json.dump({"fits": all_fits, "band_crosscheck": all_xc, "args": vars(a)}, fh, indent=2)
    print(f"wrote {a.out}_rows.csv and {a.out}_fits.json")

    if not a.no_plot:
        plot(all_fits, a.out + "_exponents.png")


def plot(fits, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ds = sorted({f["d"] for f in fits})
    fams = sorted({f["family"] for f in fits})
    fig, axes = plt.subplots(1, len(ds), figsize=(5 * len(ds), 4), squeeze=False)
    for ax, d in zip(axes[0], ds):
        for fam in fams:
            sel = sorted([f for f in fits if f["d"] == d and f["family"] == fam], key=lambda r: r["p"])
            if not sel:
                continue
            p = [r["p"] for r in sel]
            ax.plot(p, [r["slope_smallest_scales"] for r in sel], "o-", label=f"{fam} (measured)")
            ax.plot(p, [r["predicted"] for r in sel], "--", color=ax.lines[-1].get_color(), alpha=0.6, label=f"{fam} (predicted)")
        ax.axvline(d - 2, color="k", lw=0.8, ls=":")
        ax.axvline(d - 1, color="gray", lw=0.8, ls=":")
        ax.set_title(f"CP^{d-1}: endpoint exponent e(p); walls at p=d-2, d-1")
        ax.set_xlabel("p"); ax.set_ylabel("d log sup_t ||T_t f_s||_p^p / d log(1/s)")
        ax.axhline(0, color="k", lw=0.5); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=130)
    print(f"wrote {path}")


if __name__ == "__main__":
    main()
