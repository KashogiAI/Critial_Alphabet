"""Optional random-net surrogate for the grouped cap protocol.

What is implemented
-------------------
A random Haar net of L = lambda / s^{d-1} centres replaces the deterministic net of the
manuscript (lambda = expected number of centres in a cap). Shared randomness per seed:
the net, R Haar rotations (one per round) and R uniform permutations (packets).

Alice (input x):   round by round, rotate, find the k centres inside C_s(x), accept the
                   round with probability k/H, pick a uniform hit as anchor, and send
                   (round, packet index of the anchor).
Bob, grouped:      rejects unless every centre of the packet is safe (t(y,z) > s); if the
                   packet is safe he accepts with probability c / p_g, where
                   p_g = P(all g-1 peers safe | anchor safe) is hypergeometric in the
                   number B_y of unsafe centres of the rotated net.
Bob, ungrouped:    accepts iff the anchor itself is safe (needs the anchor index, i.e. an
                   alphabet of size ~L instead of ~L/n).

What is measured
----------------
1. Sampled response: acceptance frequency at fixed fidelity t versus the exact
   c K_s(t) (grouped) and K_s(t) (ungrouped) from `zonal.cap_response`. This experiment uses a finite random surrogate shared across input trials.
2. The geometric fact that makes grouping possible: the unsafe fraction B_y/L is of order
   s in every dimension (its mean is the band mass 1-(1-s)^{d-1} ~ (d-1)s).
3. Record sampled violations of the correction and hit bounds. The random list has no
   deterministic covering guarantee. Sampled ranges are not the all-input alphabet L.
4. Alphabet: distinct messages used by a dense input sample, grouped (~ lambda s^{-(d-2)})
   versus ungrouped (~ lambda s^{-(d-1)}); slopes against log(1/s) across dimensions.

Scale limits: L = lambda s^{-(d-1)} centres must fit in memory, so the reachable s range
shrinks with d. Everything is chunked; pass backend="cupy" on the GPU.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from dataclasses import dataclass

import numpy as np

from . import cpn
from . import zonal as Z


@dataclass
class Params:
    d: int = 4
    s: float = 0.05
    lam: float = 4.0            # expected centres per cap -> L = lam / s^{d-1}
    kappa_group: float = 0.25   # packet size n = floor(kappa_group / band_mass): (n-1) B_y/(L-1) <~ kappa_group
    c: float = 0.75             # target acceptance for a safe anchor; needs p_g >= c
    H: int | None = None        # hit-count bound for the round acceptance k/H
    rounds: int = 96
    seed: int = 0
    backend: str = "numpy"
    dtype: str = "complex64"
    max_fid_elems: int = 20_000_000


def safe_peer_probability(L, unsafe, size):
    """Without-replacement probability, conditional on a safe anchor."""
    unsafe, size = np.broadcast_arrays(np.asarray(unsafe), np.asarray(size))
    if np.any((unsafe < 0) | (unsafe >= L) | (size < 1) | (size > L)):
        raise ValueError("invalid safe-anchor packet population")
    prob = np.ones(unsafe.shape)
    for i in range(int(np.max(size, initial=1))-1):
        live = size > i+1
        prob[live] *= np.maximum(0, L-1-unsafe[live]-i)/(L-1-i)
    return prob


class GroupedProtocol:
    def __init__(self, P: Params):
        self.P = P
        self.xp = xp = cpn.get_xp(P.backend)
        self.dtype = getattr(xp, P.dtype)
        self.rng = xp.random.default_rng(P.seed)
        self.d, self.s = P.d, P.s
        self.L = int(math.ceil(P.lam / P.s ** (P.d - 1)))
        self.n = max(1, int(math.floor(P.kappa_group / cpn.band_mass(P.s, P.d))))
        self.H = P.H or int(math.ceil(P.lam + 6 * math.sqrt(P.lam) + 6))  # Poisson(lam) tail ~1e-10
        self.net = cpn.haar_rays(xp, self.rng, self.L, self.d, self.dtype)
        self.U = xp.stack([cpn.haar_unitary(xp, self.rng, self.d, self.dtype) for _ in range(P.rounds)])
        self._perm = {}
        self.n_packets = int(math.ceil(self.L / self.n))
        self.stats = {"max_hits": 0, "encode_failures": 0, "min_pg": 1.0, "pg_below_c": 0, "inputs": 0}

    # -- shared randomness ---------------------------------------------------------
    def perm(self, r: int):
        """(perm, inverse perm) for round r, generated deterministically from the seed."""
        if r not in self._perm:
            self._perm.clear()  # deterministic replay; keep only one round in memory
            g = np.random.default_rng([self.P.seed, 7919, r])
            p = g.permutation(self.L).astype(np.int64)
            inv = np.empty_like(p); inv[p] = np.arange(self.L)
            self._perm[r] = (self.xp.asarray(p), self.xp.asarray(inv))
        return self._perm[r]

    def _fid_to_net(self, Xr):
        """Fidelities of rotated inputs to the net, chunked: returns a generator of (slice, fid)."""
        rows = max(1, self.P.max_fid_elems // self.L)
        for i0 in range(0, Xr.shape[0], rows):
            yield slice(i0, i0 + rows), cpn.fidelity(self.xp, Xr[i0:i0 + rows], self.net)

    # -- Alice -----------------------------------------------------------------------
    def encode(self, X):
        """Returns (round, anchor index, packet index) per input; round = -1 if no round accepted."""
        xp = self.xp
        N = X.shape[0]
        rnd = np.full(N, -1, dtype=np.int64)
        anc = np.full(N, -1, dtype=np.int64)
        pending = np.arange(N)
        for r in range(self.P.rounds):
            if len(pending) == 0:
                break
            Xr = X[xp.asarray(pending)] @ self.U[r].conj()        # t(x, U z) = t(U^dag x, z)
            u1 = cpn.to_np(cpn.uniform(xp, self.rng, len(pending)))
            u2 = cpn.to_np(cpn.uniform(xp, self.rng, len(pending)))
            accepted = np.zeros(len(pending), dtype=bool)
            for sl, fid in self._fid_to_net(Xr):
                hits = fid > 1.0 - self.s
                k = cpn.to_np(hits.sum(axis=1))
                self.stats["max_hits"] = max(self.stats["max_hits"], int(k.max(initial=0)))
                acc = u1[sl] < k / self.H
                if not acc.any():
                    continue
                # uniform hit: the floor(u2*k)-th hit in index order
                target = np.floor(u2[sl] * np.maximum(k, 1)).astype(np.int64)
                cs = xp.cumsum(hits, axis=1)
                idx_target = xp.asarray(target)[:, None] + 1
                pick = cpn.to_np(xp.argmax(cs >= idx_target, axis=1))
                sel = np.nonzero(acc)[0]
                gi = pending[sl][sel]
                rnd[gi] = r
                anc[gi] = pick[sel]
                accepted[sl][sel] = True
            pending = pending[~accepted]
        self.stats["encode_failures"] += int(len(pending))
        self.stats["inputs"] += N
        if self.stats["max_hits"] > self.H:
            raise RuntimeError(f"hit count {self.stats['max_hits']} exceeded H={self.H}: increase H")
        packet = np.full(N, -1, dtype=np.int64)
        for r in np.unique(rnd[rnd >= 0]):
            m = rnd == r
            _, inv = self.perm(int(r))
            packet[m] = cpn.to_np(inv[self.xp.asarray(anc[m])]) // self.n
        return rnd, anc, packet

    # -- Bob -------------------------------------------------------------------------
    def decode(self, Y, rnd, anc, packet):
        """Returns (accept_grouped, accept_ungrouped, B_y, p_g) per pair."""
        xp = self.xp
        N = Y.shape[0]
        acc_g = np.zeros(N, dtype=bool); acc_u = np.zeros(N, dtype=bool)
        By = np.zeros(N, dtype=np.int64); pg = np.ones(N)
        for r in np.unique(rnd[rnd >= 0]):
            m = np.nonzero(rnd == r)[0]
            Yr = Y[xp.asarray(m)] @ self.U[r].conj()
            p, _ = self.perm(int(r))
            u = cpn.to_np(cpn.uniform(xp, self.rng, len(m)))
            for sl, fid in self._fid_to_net(Yr):
                unsafe = fid <= self.s
                B = cpn.to_np(unsafe.sum(axis=1)).astype(np.int64)
                ids = m[sl]
                By[ids] = B
                # ungrouped: anchor safe?
                a = xp.asarray(anc[ids])
                anchor_unsafe = cpn.to_np(unsafe[xp.arange(len(ids)), a])
                acc_u[ids] = ~anchor_unsafe
                # grouped: whole packet safe, then accept w.p. c/p_g
                pk = packet[ids]
                starts = pk * self.n
                g = np.minimum(self.n, self.L - starts)
                members = xp.asarray(starts)[:, None] + xp.arange(self.n)[None, :]
                valid = cpn.to_np(members < self.L)
                members = xp.minimum(members, self.L - 1)
                mem_ids = p[members]                                    # (rows, n) net indices
                mem_unsafe = cpn.to_np(xp.take_along_axis(unsafe, mem_ids, axis=1)) & valid
                packet_safe = ~mem_unsafe.any(axis=1)
                # hypergeometric: P(all g-1 peers safe | anchor safe)
                pgi = np.ones(len(ids))
                safe = ~anchor_unsafe
                pgi[safe] = safe_peer_probability(self.L, B[safe], g[safe])
                pg[ids] = pgi
                self.stats["min_pg"] = min(self.stats["min_pg"], float(pgi.min()))
                self.stats["pg_below_c"] += int((pgi < self.P.c).sum())
                if np.any(pgi < self.P.c):
                    raise ArithmeticError("correction c/p_g exceeds one for a safe anchor")
                ratio = self.P.c / pgi
                acc_g[ids] = packet_safe & (u[sl] < ratio)
        return acc_g, acc_u, By, pg


# --------------------------------------------------------------------------- experiment driver
def run_point(P: Params, t_list, n_pairs: int, n_alphabet: int, log=print):
    xp = cpn.get_xp(P.backend)
    t0 = time.time()
    proto = GroupedProtocol(P)
    dtype = proto.dtype
    log(f"  d={P.d} s={P.s:g}: L={proto.L} centres, packet n={proto.n}, packets={proto.n_packets}, H={proto.H}")
    out = {"d": P.d, "s": P.s, "L": proto.L, "n": proto.n, "n_packets": proto.n_packets, "H": proto.H,
           "band_mass": cpn.band_mass(P.s, P.d), "responses": []}
    for t in t_list:
        X = cpn.haar_rays(xp, proto.rng, n_pairs, P.d, dtype)
        Y = cpn.rays_at_fidelity(xp, proto.rng, X, t)
        rnd, anc, pk = proto.encode(X)
        ok = rnd >= 0
        acc_g, acc_u, By, pg = proto.decode(Y, rnd, anc, pk)
        Kg = P.c * Z.cap_response(t, P.s, P.d)
        Ku = Z.cap_response(t, P.s, P.d)
        fg, fu = float(acc_g.mean()), float(acc_u.mean())
        seg = math.sqrt(max(fg * (1 - fg), 1e-12) / n_pairs); seu = math.sqrt(max(fu * (1 - fu), 1e-12) / n_pairs)
        rec = {"t": t, "grouped_freq": fg, "grouped_se": seg, "grouped_exact": Kg, "grouped_z": (fg - Kg) / seg,
               "ungrouped_freq": fu, "ungrouped_se": seu, "ungrouped_exact": Ku, "ungrouped_z": (fu - Ku) / seu,
               "unsafe_fraction_mean": float(By[ok].mean() / proto.L) if ok.any() else None, "unsafe_fraction_max": float(By.max() / proto.L),
               "pg_min": float(pg.min()), "pairs": n_pairs, "encoded_pairs": int(ok.sum()), "failed_pairs": int((~ok).sum())}
        out["responses"].append(rec)
        log(f"    t={t:.4f}: grouped {fg:.4f}±{seg:.4f} vs cK_s={Kg:.4f} (z={rec['grouped_z']:+.2f}) | "
            f"ungrouped {fu:.4f}±{seu:.4f} vs K_s={Ku:.4f} (z={rec['ungrouped_z']:+.2f}) | "
            f"B_y/L mean {rec['unsafe_fraction_mean']} (band mass {out['band_mass']:.4g}), min p_g {rec['pg_min']:.3f}")
    # alphabet: the range at this seed is at most rounds_used * n_packets (grouped) and
    # rounds_used * L (ungrouped), and at least n_packets / lam (every packet covers at most
    # n caps of mass s^{d-1}). The distinct-messages count over a finite input sample is a
    # diagnostic only: it saturates to the range only when the sample is much larger than it.
    X = cpn.haar_rays(xp, proto.rng, n_alphabet, P.d, dtype)
    rnd, anc, pk = proto.encode(X)
    ok = rnd >= 0
    used_g = len(set(zip(rnd[ok].tolist(), pk[ok].tolist())))
    used_u = len(set(zip(rnd[ok].tolist(), anc[ok].tolist())))
    rounds_used = int(rnd[ok].max() + 1) if ok.any() else 0
    out.update({"alphabet_grouped_upper": P.rounds * proto.n_packets + 1, "alphabet_ungrouped_upper": P.rounds * proto.L + 1,
                "packets": proto.n_packets, "rounds_used": rounds_used,
                "used_grouped_sample": used_g, "used_ungrouped_sample": used_u, "n_alphabet_inputs": n_alphabet,
                "stats": dict(proto.stats), "seconds": time.time() - t0})
    log(f"    alphabet: packets {proto.n_packets} (= s^-(d-2) object), L {proto.L} (= s^-(d-1)); rounds used {rounds_used}; "
        f"declared slots incl. failure {out['alphabet_grouped_upper']}; "
        f"distinct used over {n_alphabet} inputs: grouped {used_g}, ungrouped {used_u}; "
        f"max hits {proto.stats['max_hits']} (H={proto.H}); encode failures {proto.stats['encode_failures']}; "
        f"p_g<c events {proto.stats['pg_below_c']}; {out['seconds']:.1f}s")
    return out


def fit_slopes(results):
    """log alphabet vs log(1/s) per dimension; predicted d-2 (grouped) and d-1 (ungrouped)."""
    fits = []
    for d in sorted({r["d"] for r in results}):
        rs = sorted([r for r in results if r["d"] == d], key=lambda r: -r["s"])
        if len(rs) < 2:
            continue
        x = np.log(1.0 / np.array([r["s"] for r in rs]))
        for key, pred in (("packets", d - 2), ("L", d - 1), ("alphabet_grouped_upper", d - 2), ("alphabet_ungrouped_upper", d - 1)):
            y = np.log(np.array([r[key] for r in rs], dtype=float))
            slope = np.polyfit(x, y, 1)[0]
            fits.append({"d": d, "quantity": key, "slope": float(slope), "predicted": pred})
    return fits


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--d", type=int, nargs="+", default=[4])
    ap.add_argument("--s", type=float, nargs="+", default=[0.2, 0.1, 0.05])
    ap.add_argument("--t-over-s", type=float, nargs="+", default=[0.5, 1.0, 2.0, 3.0, 4.0, 8.0])
    ap.add_argument("--lam", type=float, default=4.0)
    ap.add_argument("--kappa-group", type=float, default=0.25)
    ap.add_argument("--c", type=float, default=0.75)
    ap.add_argument("--pairs", type=int, default=20000, help="(x,y) pairs per fidelity for the exactness test")
    ap.add_argument("--alphabet-inputs", type=int, default=50000)
    ap.add_argument("--rounds", type=int, default=96)
    ap.add_argument("--max-L", type=int, default=5_000_000, help="skip (d,s) points whose net exceeds this")
    ap.add_argument("--backend", default="numpy", choices=["numpy", "cupy"])
    ap.add_argument("--dtype", default="complex64", choices=["complex64", "complex128"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=str, default="out/protocol")
    ap.add_argument("--no-plot", action="store_true")
    a = ap.parse_args(argv)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)

    results = []
    for d in a.d:
        for s in a.s:
            L = math.ceil(a.lam / s ** (d - 1))
            if L > a.max_L:
                print(f"  skip d={d} s={s}: L={L} > max-L"); continue
            P = Params(d=d, s=s, lam=a.lam, kappa_group=a.kappa_group, c=a.c, rounds=a.rounds, seed=a.seed,
                       backend=a.backend, dtype=a.dtype)
            t_list = [r * s for r in a.t_over_s if r * s < 1.0]
            results.append(run_point(P, t_list, a.pairs, a.alphabet_inputs))
    fits = fit_slopes(results)
    for f in fits:
        print(f"  d={f['d']} {f['quantity']:<22} slope {f['slope']:+.3f} (predicted {f['predicted']})")
    zs = [abs(r["grouped_z"]) for res in results for r in res["responses"]]
    print(f"  exactness: {len(zs)} grouped acceptance tests, max |z| = {max(zs):.2f}, "
          f"fraction with |z|<2: {np.mean(np.array(zs) < 2):.2f}")
    with open(a.out + "_results.json", "w") as fh:
        json.dump({"results": results, "fits": fits, "args": vars(a)}, fh, indent=2)
    with open(a.out + "_responses.csv", "w", newline="") as fh:
        rows = [{"d": res["d"], "s": res["s"], **r} for res in results for r in res["responses"]]
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f"wrote {a.out}_results.json and {a.out}_responses.csv")
    if not a.no_plot:
        plot(results, a.out)


def plot(results, prefix):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ds = sorted({r["d"] for r in results})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for d in ds:
        rs = sorted([r for r in results if r["d"] == d], key=lambda r: r["s"])
        s = np.array([r["s"] for r in rs])
        axes[0].loglog(1 / s, [r["packets"] for r in rs], "o-", label=f"d={d} grouped: packets (slope→{d-2})")
        axes[0].loglog(1 / s, [r["L"] for r in rs], "s--", color=axes[0].lines[-1].get_color(), alpha=0.6,
                       label=f"d={d} ungrouped: centres (slope→{d-1})")
    axes[0].set_xlabel("1/s"); axes[0].set_ylabel("messages per round"); axes[0].legend(fontsize=7)
    axes[0].set_title("Alphabet size: grouping drops the exponent by one")
    rows = [(res["d"], res["s"], r) for res in results for r in res["responses"]]
    axes[1].axhline(0, color="k", lw=0.5)
    for d in ds:
        zz = [(r["t"] / s_, r["grouped_z"]) for d_, s_, r in rows if d_ == d]
        axes[1].plot([z[0] for z in zz], [z[1] for z in zz], "o", label=f"d={d}")
    axes[1].axhspan(-2, 2, color="gray", alpha=0.15)
    axes[1].set_xlabel("t / s"); axes[1].set_ylabel("z-score: measured acceptance − c·K_s(t)")
    axes[1].set_title("Exactness of the grouped response"); axes[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(prefix + "_summary.png", dpi=130)
    print(f"wrote {prefix}_summary.png")


if __name__ == "__main__":
    main()
