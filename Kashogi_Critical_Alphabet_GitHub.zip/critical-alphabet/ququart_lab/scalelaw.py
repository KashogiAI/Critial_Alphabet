"""The d = 4 scale law of the manuscript (Lemma 3.1 / 3.2 / Appendix B).

    I(u)  = int_u^1 dv / (v^4 sqrt(1-v))
    f(u)  = (5/4) ( u / sqrt(1-u) - 2 u^4 I(u) )          density of U on (0,1)
    Q(k)  = E U^k = (5/4) (k+3) B(k+2, 1/2) / (k+5)       Mellin transform
    S     = (1 - sqrt(1-U)) / 2,  law eta
    dnu   = d eta / [ 20 s (1-s)^4 ]                      scale measure, nu'(0+) = 1/3

Claimed identities (all checked numerically here, independently of the proof):
    Q(0) = 1,  Q(-1) = 5/4,  nu'(0+) = 1/3,  nu is a probability law,
    E[ P_j^{(3,1)}(z) P_j^{(3,1)}(-z) ] = 0 for z = sqrt(1-U), every j >= 1,
    int_0^{1/2} K_s(t) dnu(s) = t   for every fidelity t.
"""
from __future__ import annotations

import numpy as np
from scipy.special import beta as Beta, eval_jacobi

from .zonal import _gl, _smooth_segment_nodes, cap_response


# --------------------------------------------------------------------------- I(u) in closed form
def _J(w, n: int):
    """J_n(w) = int_0^w (1 - x^2)^{-n} dx by the standard reduction."""
    w = np.asarray(w, dtype=float)
    if n == 1:
        return np.arctanh(w)
    return w / (2 * (n - 1) * (1 - w * w) ** (n - 1)) + (2 * n - 3) / (2 * (n - 1)) * _J(w, n - 1)


def I(u):
    """I(u) = 2 J_4(sqrt(1-u))  (substitution v = 1 - w^2)."""
    u = np.asarray(u, dtype=float)
    return 2.0 * _J(np.sqrt(1.0 - u), 4)


def f(u):
    u = np.asarray(u, dtype=float)
    return 1.25 * (u / np.sqrt(1.0 - u) - 2.0 * u ** 4 * I(u))


def f_of_w(w):
    """f(1 - w^2) * 2w: the density of W = sqrt(1-U) on (0,1); smooth, no endpoint singularity."""
    w = np.asarray(w, dtype=float)
    u = 1.0 - w * w
    return 1.25 * (2.0 * u - 8.0 * u ** 4 * w * _J(w, 4))


def Q_closed(k: float) -> float:
    return 1.25 * (k + 3) * Beta(k + 2, 0.5) / (k + 5)


def Q_numeric(k: float, n: int = 400) -> float:
    """E U^k by quadrature in the w variable (U = 1 - w^2)."""
    w, wt = _gl(n)
    return float(np.sum(wt * (1.0 - w * w) ** k * f_of_w(w)))


def nu_density(s):
    """nu'(s) = 4 (1-2s) f(4 s (1-s)) / [20 s (1-s)^4]."""
    s = np.asarray(s, dtype=float)
    # 4(1-2s) f(4s(1-s)) = 2 f_of_w(1-2s), which is finite at s = 1/2
    return 2.0 * f_of_w(1.0 - 2.0 * s) / (20.0 * s * (1.0 - s) ** 4)


def nu_mass(a: float, b: float, n: int = 200) -> float:
    s, w = _smooth_segment_nodes(a, b, n)
    return float(np.sum(w * nu_density(s)))


# --------------------------------------------------------------------------- Appendix B
def jacobi_cancellation(j: int, n: int = 400) -> tuple[float, float]:
    """(E[P_j(z) P_j(-z)], normaliser P_j(1) P_j(-1)) for z = sqrt(1-U) = W."""
    w, wt = _gl(n)
    pz = eval_jacobi(j, 3, 1, w)
    pm = eval_jacobi(j, 3, 1, -w)
    val = float(np.sum(wt * pz * pm * f_of_w(w)))
    b0 = float(eval_jacobi(j, 3, 1, 1.0) * eval_jacobi(j, 3, 1, -1.0))
    return val, b0


# --------------------------------------------------------------------------- Lemma 3.2
def mixture(t: float, n_s: int = 64, n_u: int = 48, n_rho: int = 48) -> float:
    """int_0^{1/2} K_s(t) dnu(s), computed from the direct cap response (no spectral input).

    K_s(t) = 1 for s < s*(t) with 4 s*(1-s*) = t; the remaining s-integral is split at
    s = t and at s = s* to keep the integrand smooth on each piece.
    """
    sstar = 0.5 * (1.0 - np.sqrt(1.0 - t)) if t < 1.0 else 0.5
    total = nu_mass(0.0, sstar)
    pts = sorted({sstar, 0.5} | ({t} if sstar < t < 0.5 else set()) | ({min(0.5, 2 * sstar)}))
    for a, b in zip(pts[:-1], pts[1:]):
        if b - a <= 0:
            continue
        s, w = _smooth_segment_nodes(a, b, n_s)
        for si, wi in zip(s, w):
            total += wi * nu_density(si) * cap_response(t, si, 4, n_u, n_rho)
    return total
