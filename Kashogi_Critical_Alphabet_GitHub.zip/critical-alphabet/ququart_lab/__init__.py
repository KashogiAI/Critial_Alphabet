"""ququart_lab: numerical laboratory for the critical communication exponent.

Modules
-------
cpn        geometry of CP^{d-1}: Haar rays, fidelity, cap/band masses, sampling
           of fidelity spheres (NumPy API; pass backend="cupy" for the GPU)
zonal      zonal (Jacobi) functions, difference-quotient multipliers, exact
           spherical means of a band via a 1-D integral, cap response K_s(t)
scalelaw   the d=4 scale law nu of the manuscript (density f, Mellin transform,
           Jacobi cancellation, mixture identity)
validate   theorem-anchored checks (d=4) and multiplier-growth checks (d>=5)
endpoint   Experiment 1: adversarial L^infty -> L^p endpoint exponents
protocol   Experiment 2: grouped encoder with random nets, exactness, scaling
"""
__version__ = "0.1.0"
