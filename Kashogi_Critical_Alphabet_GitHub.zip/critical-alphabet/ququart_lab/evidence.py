"""Two finite experiments for the critical alphabet moment manuscript. All arithmetic is float64."""
import math

import numpy as np
from scipy.stats import beta

from . import cpn

FIDELITIES = (0.0, 2**-10, 1/64, 0.125, 0.37, 0.5, 0.81, 63/64, 1.0)
TAIL_SCALES = (2**-6, 2**-8, 2**-10, 2**-12)


def interval(hits, total, alpha):
    """Two-sided exact binomial interval, including at the endpoints."""
    if total <= 0 or not 0 <= hits <= total:
        raise ValueError(f"invalid binomial counts {hits}/{total}")
    lower = beta.ppf(alpha/2, hits, total-hits+1) if hits else 0.0
    upper = beta.isf(alpha/2, hits+1, total-hits) if hits < total else 1.0
    return float(lower), float(upper)


def envelope(d):
    factor = 1.0
    for j in range(4, d):
        atom = (j+2)/(2*j)
        cont = (j+2)*(j*j-1)/(4*j*(j+3)*((j-1)/2))
        factor *= atom + cont
    return 10 * 2**(d-1) * factor / (d*(d+1))


def propose_scales(xp, rng, d, size):
    # Importance-sample the U^{-1} tilt. Cancel the singularity analytically.
    w = rng.random(size)
    u = (1-w)*(1+w)
    # u^3 J_4(w) by reduction, with atanh(w) written without division.
    atanh = 0.5*(xp.log1p(w)-xp.log(xp.maximum(1-w, np.finfo(float).tiny)))
    reduced = w/6 + 5*w*u/24 + 5*w*u*u/16 + 5*u**3*atanh/16
    weight = 2.5*(1-4*w*reduced)
    for j in range(4, d):
        atom = (j+2)/(2*j)
        shape = (j-1)/2
        mass = (j+2)*(j*j-1)/(4*j*(j+3)*shape)
        norm = atom + mass
        continuous = rng.random(size) >= atom/norm
        v = rng.random(size)**(1/shape)
        u *= xp.where(continuous, v, 1.0)
        weight *= norm*xp.where(continuous, 1-8*v**((j+3)/2)/(j*j-1), 1.0)
    s = u/(2*(1+xp.sqrt(xp.maximum(0.0, 1-u))))
    weight *= 4/(d*(d+1)*(1-s)**(d-1))
    return s, weight


def direct_score(xp, t, radial, perp, cosine):
    # Squared complex amplitude at the test ray. radial = 1 - anchor fidelity.
    a = xp.sqrt(t*(1-radial))
    b = xp.sqrt((1-t)*radial*perp)
    return (a-b)**2 + 2*a*b*(1+cosine)


def born_job(xp, rng, d, proposals, alpha, tolerance, batch=131072):
    counts = np.zeros(len(FIDELITIES), np.int64)
    tail = np.zeros(len(TAIL_SCALES), np.int64)
    kept = mutant = 0
    bound = envelope(d)
    for lo in range(0, proposals, batch):
        size = min(batch, proposals-lo)
        s, weight = propose_scales(xp, rng, d, size)
        if not bool(xp.all(xp.isfinite(weight) & (weight >= 0) & (weight <= bound*(1+1e-14)))):
            raise ArithmeticError("scale weight violated its analytic envelope")
        accepted = rng.random(size)*bound < weight
        s = s[accepted]
        n = len(s)
        kept += n
        radial = s*rng.random(n)**(1/(d-1))
        perp = 1-rng.random(n)**(1/(d-2))
        cosine = xp.cos(2*math.pi*rng.random(n))
        hits = [xp.count_nonzero(direct_score(xp,t,radial,perp,cosine) > s) for t in FIDELITIES]
        counts += cpn.to_np(xp.stack(hits)).astype(np.int64)
        tail += cpn.to_np(xp.stack([xp.count_nonzero(s < v) for v in TAIL_SCALES])).astype(np.int64)
        mutant += int(xp.count_nonzero(radial*perp > s*s))  # wrong decoder threshold at t=0
    if not kept:
        raise RuntimeError("zero accepted scales")
    records = []
    for t, k in zip(FIDELITIES,counts):
        k = int(k)
        low, high = interval(k,kept,alpha)
        records.append(dict(t=t, hits=k, trials=kept, rate=k/kept, low=low, high=high,
                            target_inside=low <= t <= high,
                            within_tolerance=max(high-t,t-low) <= tolerance))
    ml, mh = interval(kept,proposals,alpha)
    return dict(proposals=proposals, accepted=kept, envelope=bound, predicted_acceptance=1/bound,
                mass_interval=[ml,mh], mass_ok=ml <= 1/bound <= mh,
                mutant_false_accepts=mutant, mutant_detected=mutant > 0,
                responses=records, small_scale=[dict(s=s, hits=int(k), trials=kept,
                    mass_over_s=k/(kept*s), interval_over_s=[v/s for v in interval(int(k),kept,alpha)])
                    for s,k in zip(TAIL_SCALES,tail)])


def witness_job(xp, rng, centres, kappa, trials, alpha):
    n, d = centres.shape
    s = kappa/((d-1)*n)
    t = 5*s
    if not 0 < t <= 0.5:
        raise ValueError("witness must lie in the theorem's fidelity interval")
    Y = xp.asarray(centres)
    unique_count = successes = 0
    # Cap-tagged sampling avoids waiting for a Haar point to hit a microscopic cap.
    # Limit temporaries by centre count, not installed VRAM.
    batch = min(8192, max(1, 2**20//n))
    for lo in range(0, trials, batch):
        size = min(batch, trials-lo)
        idx = rng.integers(n,size=size)
        C = Y[idx]
        v = s*rng.random((size,1))**(1/(d-1))
        w = cpn._orthonormal_perp(xp,rng,C,1)[:,0,:]
        X = xp.sqrt(1-v)*C + xp.sqrt(v)*w
        Z = cpn.rays_at_fidelity(xp,rng,X,t)
        fx = cpn.fidelity(xp,X,Y)
        selected = fx[xp.arange(size),idx]
        if bool(xp.any(selected <= 1-s)):
            raise ArithmeticError("sample outside tagged cap")
        unique = (fx > 1-s).sum(axis=1) == 1
        fz = cpn.fidelity(xp,Z,Y)
        if bool(xp.any(fz[xp.arange(size),idx] <= s)):
            raise ArithmeticError("sphere did not escape its tagged band")
        unique_count += int(xp.count_nonzero(unique))
        successes += int(xp.count_nonzero(unique & (fz.min(axis=1) > s)))
    h = s**(d-1)
    band = -math.expm1((d-1)*math.log1p(-s))
    prediction = math.exp((n-1)*math.log1p(-h-band))
    low, high = interval(successes,trials,alpha)
    powers = []
    for p in (d-2,d-1):
        lower = n*h*(low/t)**p
        powers.append(dict(p=p, lower_bound=lower, scaled_bound=lower*s**(p-(d-2))))
    return dict(n=n, s=s, t=t, kappa=kappa, trials=trials, unique=unique_count, hits=successes,
                rate=successes/trials, interval=[low,high], ensemble_prediction=prediction,
                strong_witness=low >= prediction/2, bounds=powers, tested_fidelities=2*n*trials)


def parity(xp):
    """An independent host fixture exercises the actual GEMM + radial formula on the chosen backend."""
    r = np.random.default_rng(7341)
    X = cpn.haar_rays(np,r,131,6)
    Y = cpn.haar_rays(np,r,53,6)
    ref = np.array([[abs(np.vdot(x,y))**2 for y in Y] for x in X])
    got = cpn.to_np(cpn.fidelity(xp,xp.asarray(X),xp.asarray(Y)))
    err = float(np.max(np.abs(ref-got)))
    v, rho, angle = r.random((3,400))
    t = 0.37
    direct = np.abs(np.sqrt(t*(1-v))+np.exp(2j*np.pi*angle)*np.sqrt((1-t)*v*rho))**2
    test = direct_score(xp,t,xp.asarray(v),xp.asarray(rho),xp.cos(2*np.pi*xp.asarray(angle)))
    err = max(err,float(np.max(np.abs(direct-cpn.to_np(test)))))
    if not err < 2e-13:
        raise ArithmeticError(f"CPU fixture disagrees with selected backend by {err}")
    return err


def packet_job(xp, rng, trials, alpha, tolerance):
    """Explicit random packet permutations with fixed safe anchor; independent of scale sampling."""
    from .protocol import safe_peer_probability
    rows = []
    for L,B,g in ((65,16,2),(67,2,8),(67,2,3),(65,16,1)):
        pg = float(safe_peer_probability(L,B,g))
        if pg < 0.75:
            raise ArithmeticError("illegal packet correction")
        safe = accepted = 0
        for lo in range(0,trials,8192):
            n = min(8192,trials-lo)
            ranks = xp.argsort(rng.random((n,L-1)),axis=1)
            clean = (ranks[:,:g-1] >= B).all(axis=1)
            safe += int(xp.count_nonzero(clean))
            accepted += int(xp.count_nonzero(clean & (rng.random(n) < 0.75/pg)))
        low, high = interval(accepted,trials,alpha)
        sl, sh = interval(safe,trials,alpha)
        rows.append(dict(population=L, unsafe=B, size=g, trials=trials, all_safe=safe,
                         p_g=pg, safe_interval=[sl,sh], accepted=accepted, target=0.75,
                         interval=[low,high], target_inside=(sl <= pg <= sh and low <= 0.75 <= high),
                         within_tolerance=max(high-0.75,0.75-low) <= tolerance))
    return dict(cases=rows)
