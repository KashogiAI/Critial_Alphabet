"""Preregistered, resumable RTX evidence run. One immutable result per experiment and seed."""
import argparse
import fcntl
import hashlib
import json
import math
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time
import zipfile

import numpy as np
import scipy

from . import cpn, evidence as ev

ROOT = Path(__file__).resolve().parents[1]
SOURCE = sorted([*ROOT.glob("ququart_lab/*.py"), ROOT/"check_dimension.py", ROOT/"PLAN.md", ROOT/"run_gpu.sh", ROOT/"requirements.txt", *ROOT.glob("tests/test*.py")])
BASE_SEED = 509031
TOLERANCE = 0.012
FAMILY_ALPHA = 0.01


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False)+"\n")
    tmp.replace(path)


def seed_for(wave, kind, d, n, stream=0):
    return int(np.random.SeedSequence([BASE_SEED,wave,kind,d,n,stream]).generate_state(1, dtype=np.uint64)[0])


def schedule(wave, smoke):
    dims = (4,5) if smoke else (4,5,6,7,8)
    sizes = (2,16) if smoke else (2,8,32,128,512)
    if wave >= 3 and not smoke:
        sizes = (32,128,512,2048,4096)
    tasks = [("packets",0,0)]
    # Round-robin across dimensions; record a useful result even with a short budget.
    tasks += [("born",d,0) for d in dims]
    tasks += [("witness",d,n) for n in sizes for d in dims]
    return tasks


def identity(xp, backend, smoke):
    env = dict(backend=backend, profile="smoke" if smoke else "overnight",
               python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
               machine=platform.machine(), platform=platform.platform(), device="CPU",
               source={str(p.relative_to(ROOT)):digest(p) for p in SOURCE})
    if backend == "cupy":
        r = xp.cuda.runtime
        props = r.getDeviceProperties(xp.cuda.Device().id)
        name = props["name"]
        env.update(device=name.decode() if isinstance(name,bytes) else str(name),
                   compute_capability=xp.cuda.Device().compute_capability,
                   cuda_runtime=r.runtimeGetVersion(), cuda_driver=r.driverGetVersion(),
                   cupy=xp.__version__, vram_bytes=int(props["totalGlobalMem"]))
        if "5090" not in env["device"]:
            raise RuntimeError(f"RTX 5090 requested; selected device is {env['device']}. Set CUDA_VISIBLE_DEVICES.")
    return env


def anchors(out, xp):
    fixture = ev.parity(xp)
    for name,args in (("regression",[str(ROOT/"tests/test_evidence.py")]),
                      ("geometry",[str(ROOT/"tests/test_core.py")]),
                      ("analytic",[str(ROOT/"check_dimension.py")]),
                      ("quadrature",["-m","ququart_lab.validate","--lmax","400","--dmax","8",
                                     "--json",str(out/"quadrature.json")])):
        proc = subprocess.run([sys.executable,*args],cwd=ROOT,text=True,
                              stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (out/f"{name}.log").write_text(proc.stdout)
        if proc.returncode:
            raise RuntimeError(f"{name} validation failed; see {out/name}.log")
    return dict(shared_fixture_max_abs_error=fixture, regression_pass=True, analytic_pass=True,
                quadrature_pass=json.loads((out/"quadrature.json").read_text())["all_pass"])


def data_for(out,name):
    return out/"cells"/(name+".json")


def run_cell(out,xp,wave,kind,d,n,smoke,alpha):
    name = f"w{wave:04d}-{kind}-d{d}-n{n}"
    path = data_for(out,name)
    if path.exists():
        return False
    category = {"born":1,"witness":2,"packets":3}[kind]
    seed = seed_for(wave,category,d,n)
    rng = xp.random.default_rng(seed)
    started = time.monotonic()
    tolerance = 0.060 if smoke else TOLERANCE
    if kind == "born":
        result = ev.born_job(xp,rng,d,2**16 if smoke else 2**22,alpha,tolerance)
    elif kind == "packets":
        result = ev.packet_job(xp,rng,2**13 if smoke else 2**18,alpha,tolerance)
    else:
        centre_seed = seed_for(wave,category,d,n,stream=1)
        Y = cpn.haar_rays(np,np.random.default_rng(centre_seed),n,d)
        kappa = 0.5 if wave < 3 else (0.25,0.5,1.0,2.0)[(wave-3)%4]
        result = ev.witness_job(xp,rng,Y,kappa,2**12 if smoke else 2**17,alpha)
        file = path.with_suffix(".npy")
        with file.with_suffix(".tmp").open("wb") as dest:
            np.save(dest,Y,allow_pickle=False)
        file.with_suffix(".tmp").replace(file)
        result.update(centre_seed=centre_seed, centres=file.name, centres_sha256=digest(file))
    runtime = time.monotonic()-started
    write_json(path,dict(wave=wave,kind=kind,d=d,seed=seed,cell=name,alpha=alpha,
                         tolerance=tolerance,seconds=runtime,**result))
    print(f"[{name}] {runtime:.1f}s",flush=True)
    return True


def findings(row):
    if row["kind"] == "born":
        flags = []
        if not row["mass_ok"]:
            flags.append("scale normalization")
        if not row["mutant_detected"]:
            flags.append("negative control undetected")
        for h in row["responses"]:
            if not h["target_inside"] or not h["within_tolerance"]:
                flags.append(f"Born t={h['t']:g}")
        return flags
    if row["kind"] == "packets":
        return [f"packet size={h['size']}" for h in row["cases"]
                if not (h["target_inside"] and h["within_tolerance"])]
    return [] if row["strong_witness"] else ["weak finite witness"]


def load_rows(out,verify=True):
    rows = []
    for p in sorted((out/"cells").glob("*.json")):
        row = json.loads(p.read_text())
        if verify and row["kind"] == "witness" and digest(p.with_name(row["centres"])) != row["centres_sha256"]:
            raise ValueError(f"saved decoder checksum mismatch in {p}")
        rows.append(row)
    return rows


def summary(out,env,smoke,final=False):
    rows = load_rows(out,verify=final)
    core_waves = 1 if smoke else 3
    wanted = {f"w{w:04d}-{k}-d{d}-n{n}" for w in range(core_waves) for k,d,n in schedule(w,smoke)}
    done = {r["cell"] for r in rows}
    missing = sorted(wanted-done)
    flags = [(r["cell"],f) for r in rows for f in findings(r)]
    verdict = "REVIEW" if flags else ("INCOMPLETE" if missing else "FINITE CHECKS PASSED")
    if smoke:
        verdict = "SMOKE ONLY / "+verdict
    write_json(out/"status.json",dict(verdict=verdict,core_completed=len(wanted)-len(missing),
               core_required=len(wanted),completed_cells=len(rows),missing_core=missing,flags=flags))
    born = [r for r in rows if r["kind"]=="born"]
    witness = [r for r in rows if r["kind"]=="witness"]
    packets = [r for r in rows if r["kind"]=="packets"]
    bcount = sum(r["accepted"] for r in born)
    fidelities = sum(r["tested_fidelities"] for r in witness)
    response = [(abs(h["rate"]-h["t"]),r,h) for r in born for h in r["responses"]]
    text = [f"# {env['device']} evidence report","",f"**{verdict}**",
            "",f"{len(wanted)-len(missing)} of {len(wanted)} prespecified core cells complete. "
            f"{len(rows)} total cells, including replication. Backend {env['backend']} in double precision.",
            "",f"Accepted cap anchors: {bcount:,} from {sum(r['proposals'] for r in born):,} proposals. "
            f"Test bits evaluated: {len(ev.FIDELITIES)*bcount:,} (the fidelities share anchors). "
            f"Endpoint pairwise centre fidelities: {fidelities:,}. "
            f"Permutation trials: {sum(h['trials'] for r in packets for h in r['cases']):,}."]
    if response:
        err,r,h=max(response,key=lambda u:u[0])
        text += ["",f"Largest absolute Born residual {err:.6g} in {r['cell']} at t={h['t']}. "
                 f"Observed {h['hits']:,}/{h['trials']:,}. Simultaneous interval [{h['low']:.6g}, {h['high']:.6g}]."]
    if witness:
        text += ["","### Finest core scale per dimension","",
                 "Bounds below use the smallest certificate across the completed core seeds at that scale. "
                 "The quantity certified is the p-th power of the norm on the full space.",
                 "","| d | Centres | s | p | Lower bound | Seeds complete |","|---:|---:|---:|---:|---:|---:|"]
        for d in sorted({r["d"] for r in witness}):
            ws=[r for r in witness if r["d"]==d and r["wave"]<core_waves]
            if not ws:
                continue
            n=max(r["n"] for r in ws)
            sel=[r for r in ws if r["n"]==n]
            h=sel[0]
            text.append(f"| {d} | {n} | {h['s']:.6g} | {d-1} | {min(r['bounds'][1]['lower_bound'] for r in sel):.6g} | {len(sel)} |")
    text += ["","### Interpretation","",
             "The sampled component is the cap mixture for pure preparations and one rank-one binary test. "
             "The packet panel isolates Bob's conditional correction. The saved decoders give finite lower "
             "confidence bounds for the fidelity difference quotient. The run neither implements the full "
             "all-input routing construction nor measures its used alphabet or the universal converse.",
             "","Use status.json for all flags and missing core cells. Each cell file contains the counts, "
             "parameters, interval and seed. PLAN.md specifies the decision rules. "
             "Every extension flag is retained even after the core finishes."]
    if flags:
        text += ["","### Findings requiring review",""] + [f"- {k} — {f}" for k,f in flags[:40]]
    tmp = out/"report.tmp"
    tmp.write_text("\n".join(text)+"\n"); tmp.replace(out/"REPORT.md")
    if final and rows:
        plot(out,born,witness)
    return verdict


def plot(out,born,witness):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(11,4.7),layout="constrained")
    for d in sorted({r["d"] for r in born}):
        r=next(r for r in born if r["d"]==d)  # wave zero, fixed prospectively
        h=r["responses"]
        x=np.array([v["t"] for v in h]); y=np.array([v["rate"] for v in h])
        axes[0].errorbar(x,y-x,yerr=[y-[v["low"] for v in h],[v["high"] for v in h]-y],
                         marker=".",lw=0.8,alpha=0.8,label=f"d={d}")
    axes[0].axhline(0,color="black",lw=0.8)
    axes[0].set(xlabel="Target fidelity",ylabel="Observed probability minus target",title="Cap mixture • wave 1")
    for d in sorted({r["d"] for r in witness}):
        ws=sorted([r for r in witness if r["d"]==d and r["wave"]==0],key=lambda v:v["n"])
        axes[1].loglog([1/r["s"] for r in ws],[r["bounds"][1]["lower_bound"] for r in ws],
                       "o-",ms=3,label=f"d={d}")
    axes[1].set(xlabel="Inverse band scale  1/s",ylabel="Lower bound for the (d−1)-th moment",
                title="Explicit decoders • wave 1")
    for ax in axes:
        if ax.lines:
            ax.legend(fontsize=8)
    fig.savefig(out/"evidence.png",dpi=150); plt.close(fig)


def bundle(out):
    target=out/"evidence.zip"
    with zipfile.ZipFile(out/"bundle.tmp","w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob("*")):
            if p.is_file() and p.suffix not in {".tmp",".lock",".zip"}:
                z.write(p,p.relative_to(out))
        for p in SOURCE:
            z.write(p,Path("source")/p.relative_to(ROOT))
    (out/"bundle.tmp").replace(target)


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--backend",choices=("cupy","numpy"),default="cupy")
    ap.add_argument("--profile",choices=("overnight","smoke"),default="overnight")
    ap.add_argument("--hours",type=float,default=8)
    ap.add_argument("--core-only",action="store_true",help="stop after the fixed independent core panel")
    ap.add_argument("--out",type=Path)
    args=ap.parse_args(argv)
    if not __debug__:
        ap.error("validation requires normal Python; unset PYTHONOPTIMIZE")
    if not math.isfinite(args.hours) or args.hours <= 0:
        ap.error("--hours must be positive and finite")
    smoke=args.profile=="smoke"
    out=(args.out or ROOT/"runs"/f"{args.backend}-{args.profile}").resolve()
    out.mkdir(parents=True,exist_ok=True); (out/"cells").mkdir(exist_ok=True)
    lock=(out/"run.lock").open("w")
    try:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        ap.error("this run directory is already active")
    xp=cpn.get_xp(args.backend)
    env=identity(xp,args.backend,smoke)
    manifest=out/"manifest.json"
    if manifest.exists() and env != json.loads(manifest.read_text()):
        ap.error("source, backend or environment changed; choose a fresh --out")
    write_json(manifest,env)
    print(f"{env['device']} / {env['backend']} • results in {out}",flush=True)
    stop=False
    def finish_cell(*unused):
        nonlocal stop
        stop=True
        print("Stop requested; finishing current cell.",flush=True)
    for sig in (signal.SIGINT,signal.SIGTERM):
        signal.signal(sig,finish_cell)
    start=time.monotonic()
    deadline=start+args.hours*3600
    # Anchors are recorded anew on each launch, including resume.
    write_json(out/"anchors.json",anchors(out,xp))
    wave=0
    known=load_rows(out)
    done={r["cell"] for r in known}
    last_report=time.monotonic()
    while not stop and time.monotonic()<deadline:
        previous_count=len(done)
        tasks=schedule(wave,smoke)
        # Per-wave counts of *intervals*, including descriptive tail intervals.
        dims=len({d for k,d,n in tasks if k=="born"})
        n_intervals=dims*(len(ev.FIDELITIES)+len(ev.TAIL_SCALES)+1)+8+sum(k=="witness" for k,d,n in tasks)
        alpha=FAMILY_ALPHA/((wave+1)*(wave+2)*n_intervals)
        for k,d,n in tasks:
            if stop or time.monotonic()>=deadline:
                break
            key=f"w{wave:04d}-{k}-d{d}-n{n}"
            if key not in done:
                run_cell(out,xp,wave,k,d,n,smoke,alpha)
                done.add(key)
                if time.monotonic()-last_report>=60:
                    summary(out,env,smoke); last_report=time.monotonic()
        wave+=1
        if smoke or (args.core_only and wave>=3):
            break
        if any(f"w{wave-1:04d}-{k}-d{d}-n{n}" not in done for k,d,n in tasks):
            break
        if len(done)==previous_count:
            continue
        decision=summary(out,env,smoke)
        print(f"Wave {wave} complete / {decision} / elapsed {(time.monotonic()-start)/60:.1f} min",flush=True)
    decision=summary(out,env,smoke,True)
    bundle(out)
    print(f"{decision} • {out/'REPORT.md'} • {out/'evidence.zip'}",flush=True)
    return 2 if "REVIEW" in decision else (3 if "INCOMPLETE" in decision else 0)


if __name__=="__main__":
    sys.exit(main())
