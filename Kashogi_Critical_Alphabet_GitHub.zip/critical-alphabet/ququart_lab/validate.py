"""Theorem-anchored validation. Run:  python -m ququart_lab.validate [--lmax 400] [--dmax 8]

Every check prints PASS/FAIL against an explicit tolerance. The d = 4 checks pin the
code to statements proved in the manuscript; if any of them fails, nothing downstream
should be trusted. The d >= 5 multiplier-growth check probes the *claimed* (unproved)
uniform bound |m_l(t)| <= C_d l^{-(d-4)}; it is reported, not asserted.
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np

from . import scalelaw as S
from . import zonal as Z


def _report(name, value, target, tol, results, note=""):
    ok = np.isfinite(value) and abs(value - target) <= tol
    results.append({"check": name, "value": value, "target": target, "tol": tol, "pass": bool(ok), "note": note})
    print(f"[{'PASS' if ok else 'FAIL'}] {name:<46} {value:+.12g}   (target {target:+.6g}, tol {tol:g}) {note}")
    return ok


def run(lmax: int = 400, dmax: int = 8, verbose: bool = True):
    results = []
    t0 = time.time()
    print("== d = 4: statements proved in the manuscript ==")

    # Lemma A.1: sup |m_l(t)| = 2, approached as l -> inf at t -> 0+
    sup, (l, t) = Z.multiplier_sup(4, lmax)
    _report("Lemma A.1  sup|m_l(t)|, l<=%d" % lmax, sup, 2.0, 2.0 - 1.9999, results,
            note=f"attained at l={l}, t={t:g}; must stay < 2")
    assert sup < 2.0, "multiplier exceeded 2: Lemma A.1 would be false"
    # the explicit level-1 and level-2 quotients from the proof
    _report("Lemma A.1  m_1(t) = 4/3 (any t)", float(Z.multiplier(1, 0.3, 4)), 4 / 3, 1e-12, results)
    _report("Lemma A.1  m_2(1/2) = (15/2-10)/6", float(Z.multiplier(2, 0.5, 4)), (7.5 - 10) / 6, 1e-12, results)

    # Lemma 3.1
    _report("Lemma 3.1  Q(0) = 1 (f is a density)", S.Q_numeric(0), 1.0, 1e-10, results)
    _report("Lemma 3.1  Q(-1) = 5/4", S.Q_numeric(-1), 1.25, 1e-10, results)
    _report("Lemma 3.1  Q(2) closed = numeric", S.Q_numeric(2) - S.Q_closed(2), 0.0, 1e-10, results)
    grid = np.linspace(1e-6, 1 - 1e-9, 200000)
    _report("Lemma 3.1  grid f(u) > 0 on (0,1)", float(np.all(S.f(grid) > 0)), 1.0, 0.0, results,
            note=f"minimum {np.min(S.f(grid)):.6g}")
    assert np.all(S.f(grid) > 0), "scale density went negative"
    _report("Lemma 3.1  nu'(0+) = 1/3", float(S.nu_density(1e-9)), 1 / 3, 1e-6, results)
    sgrid = np.linspace(1e-6, 0.5, 100000)
    density_max = float(np.max(S.nu_density(sgrid) * (1 - sgrid) ** 3))
    _report("Lemma 3.1  nu'(s) <= (1-s)^-3", float(density_max <= 1+1e-12), 1.0, 0.0, results,
            note=f"grid maximum {density_max:.12g}")
    _report("Lemma 3.2  nu((0,1/2]) = 1", S.nu_mass(0.0, 0.5, 400), 1.0, 1e-10, results)

    # Appendix B
    worst = 0.0
    for j in range(1, 41):
        v, b0 = S.jacobi_cancellation(j)
        worst = max(worst, abs(v / b0))
    _report("App. B     max_j<=40 |E P_j(z)P_j(-z)| / b0", worst, 0.0, 1e-12, results)

    # Lemma 3.2 by direct integration (independent of the spectral proof)
    worst = 0.0
    for t in (0.01, 0.05, 0.2, 0.37, 0.5, 0.7, 0.9, 0.99):
        worst = max(worst, abs(S.mixture(t) - t))
    _report("Lemma 3.2  max_t |int K_s(t) dnu - t|", worst, 0.0, 1e-6, results,
            note="direct cap response, 3-level quadrature")

    # Lemma 2.1 cap response endpoints
    _report("Lemma 2.1  K_s(0) = 0", Z.cap_response(0.0, 0.05, 4), 0.0, 1e-10, results)
    _report("Lemma 2.1  K_s(1) = 1", Z.cap_response(1.0, 0.05, 4), 1.0, 1e-10, results)
    _report("Lemma 2.1  K_s(t) = 1 for t > 4s(1-s)", Z.cap_response(4 * 0.05 * 0.95 + 1e-3, 0.05, 4), 1.0, 1e-10, results)

    print("\n== d >= 5: multiplier growth (claimed uniform bound |m_l(t)| <= C_d l^{-(d-4)}) ==")
    tgrid = np.geomspace(1e-7, 0.5, 300)
    growth = {}
    for d in range(4, dmax + 1):
        vals = []
        for l in range(1, lmax + 1):
            m = np.max(np.abs(Z.multiplier(l, tgrid, d)))
            m = max(m, abs(Z.phi_prime0(l, d)))
            vals.append(m * l ** (d - 4))
        vals = np.array(vals)
        growth[d] = {"sup_scaled": float(vals.max()), "tail_mean_last_50": float(vals[-50:].mean()),
                     "argmax_l": int(vals.argmax()) + 1}
        print(f"  d={d}: sup_l |m_l| l^(d-4) = {vals.max():.6f} at l={vals.argmax()+1}; "
              f"mean over l in [{lmax-49},{lmax}] = {vals[-50:].mean():.6f}  "
              f"({'bounded' if vals[-50:].mean() < 1.5 * vals[:50].max() + 1e-9 else 'GROWING?'})")

    npass = sum(r["pass"] for r in results)
    print(f"\n{npass}/{len(results)} checks passed in {time.time()-t0:.1f}s")
    return {"checks": results, "multiplier_growth": growth, "all_pass": npass == len(results)}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lmax", type=int, default=400)
    ap.add_argument("--dmax", type=int, default=8)
    ap.add_argument("--json", type=str, default=None, help="write results to this JSON file")
    a = ap.parse_args(argv)
    out = run(a.lmax, a.dmax)
    if a.json:
        with open(a.json, "w") as fh:
            json.dump(out, fh, indent=2)
    sys.exit(0 if out["all_pass"] else 1)


if __name__ == "__main__":
    main()
