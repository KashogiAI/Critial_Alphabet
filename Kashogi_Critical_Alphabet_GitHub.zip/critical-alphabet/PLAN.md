# Finite evidence plan

## Scope and endpoints

The manuscript's resource is the count D of labels used over **all** preparations on one fixed public random tape. Its target is one exact binary rank-one projective test on a pure complex state. It claims a critical moment of 1/(d−2) for d ≥ 4, divergence at that moment for every exact simulator, and a matching tail for a particular construction. This lab tests three implications and component calculations. It does not sample D, implement the entire deterministic net and routing construction, test arbitrary POVMs, or verify the universal lower bound by enumeration.

## Locked overnight panel

The first three waves use independent seeded streams, d = 4, 5, 6, 7, 8, and 31 cells per wave. Each wave runs five direct cap mixtures, one finite packet experiment and 25 realized decoder experiments. The fixed inputs are listed in evidence.py; the exact seed mapping and budgets are in campaign.py. The base seed is 509031. Core runs use 4,194,304 proposals per dimension, 131,072 trials per decoder and 262,144 trials per packet configuration. All data are double precision. Every decoder is archived with its SHA-256. The hardware/software and source manifest is written before sampling. Independent seeds refer to separate pseudorandom streams. Shared anchors across different test fidelities induce dependence.

After three waves the schedule changes to larger unions (32, 128, 512, 2,048 and 4,096 bands), cycles through four prespecified densities and uses new independent centre lists. The time limit is checked between cells. Each relaunch gets a fresh wall-clock budget and resumes the same sequence. New code or a different environment requires a new run directory. The smoke profile tests plumbing at smaller counts and two dimensions.

## Direct test of the Born probability

The code samples the scale law and generates a Haar-uniform cap anchor. With x chosen by symmetry, its perpendicular squared length is radial = s V^(1/(d−1)) for uniform V. The squared projection onto a fixed transverse direction is an independent Beta(1,d−2) variate. An independent uniform phase and the actual overlap test then produce the bit. No Born probability enters the output coin. Nine fixed fidelities include 0, 1/1024, 1/64, 1/8, .37, .5, .81, 63/64 and 1. The reference rates are t. Quadrature on the original d=4 implementation is a separate anchor.

To sample the manuscript's mixing law, propose w = sqrt(1−U4) uniformly. Its tilted density f_W(w)/U4 is bounded by 5/2. For each dimension step j, divide the law of V_j by v before sampling. Its atom has mass A=(j+2)/(2j). The continuous density is bounded by a multiple of v^((j−1)/2−1) with integral B=(j+2)(j²−1)/(4j(j+3)((j−1)/2)). Propose the atom or a power-distributed variate in proportions A:B. Multiply the likelihood ratio by A+B, with the extra factor 1−8v^((j+3)/2)/(j²−1) on continuous draws. Multiply U4 by the independent V_j, set s=U/[2(1+sqrt(1−U))], and multiply the weight by 4/[d(d+1)(1−s)^(d−1)]. This converts the U inverse tilt to the desired scale law. Accept independently with probability weight/envelope(d). The proposal distribution and the geometric test do not use target outcomes. The predicted accepted fraction is 1/envelope(d), an independent normalization check. Frequencies below four small scales are recorded to inspect the prediction ν((0,s])/s → (d−3)/(d−1); no finite scale equals that limit by assumption.

A deliberately faulty decoder uses threshold s² at t=0 on the same accepted anchors. A correct decoder must always reject there. The control must yield at least one false accept. The shared CPU fixture independently computes complex inner products and cap response amplitudes by a different expression and tests the selected backend at 2×10⁻¹³ absolute tolerance. The analytic anchor also includes the wrong-denominator example and exact rational checks from the current manuscript companion.

## A direct lower bound from a saved decoder

Fix n centre rays and let f be the indicator of the union of their fidelity bands of width s. Choose a uniform index j, then a uniform X from its cap of Haar mass h=s^(d−1). Let t=5s ≤ 1/2 and draw Z on the fidelity-t sphere about X. Count success when X is in exactly one centre cap and Z is outside every band. For fixed centres these independent trials have a single probability m. The orthogonal sphere at a tagged X is entirely inside the j-th band. Hence R₀f(X)=1. The tagged band is always escaped at fidelity t, since t>4s(1−s).

Write e(X)=1−R_t f(X). The tagged mixture has density multiplicity/(nh) relative to Haar. On the uniquely covered region A, its density is 1/(nh), so ∫_A e dμ=nh m and μ(A)≤nh. Hölder for p≥1 gives

    ∥T_t f∥_p^p ≥ t^(−p) ∫_A e^p dμ ≥ nh (m/t)^p.

An exact binomial lower confidence limit for m therefore yields a lower confidence limit for the **full-space** moment of this specific decoder. These are statistical certificates, not deterministic interval-arithmetic bounds. They avoid nonlinear inner Monte Carlo bias. We report p=d−2 and p=d−1, using the same interval for both.

There is an analytic ensemble benchmark. Conditional on X,Z, another independent Haar centre must avoid the cap around X (mass h) and the band perpendicular to Z (mass b=1−(1−s)^(d−1)). Those sets are disjoint by the same escape inequality. The tagged centre already satisfies both trial requirements with respect to its own band. Therefore E_centres m = (1−h−b)^(n−1). This is an ensemble mean, not the predicted success rate of every fixed decoder.

This also gives a short independent obstruction above the endpoint. Jensen gives E_centres ∥T_t f∥_p^p ≥ nh t^(−p)(1−h−b)^(p(n−1)). With s=κ/[(d−1)n] and fixed κ>0, this is asymptotic **as a lower bound** to [κ/(d−1)] 5^(−p) exp(−pκ) s^(d−2−p). For every sufficiently small scale in this sequence at least one finite union attains that bound. In particular, for any finite p>d−2 the operator family cannot have a uniform L∞ → Lᵖ bound. The argument gives only the divergent side and concerns the analytic operator; it makes no claim of priority. Neither the endpoint upper bound nor the communication converse follows from these trials.

## Finite packet check

Condition on a safe anchor and a prescribed population. Explicit random permutations pick g−1 neighbours without replacement. If they are safe, accept with the manuscript's 0.75/p_g correction. Both the all-safe frequency and final 0.75 rate are checked. The four populations exercise a full packet, a short last packet, a singleton and the boundary p_g=0.75. These trials isolate the decoder rule. The original random-net simulation remains available for exploration; outcomes with exhausted rounds now count as rejections.

## Decision rules

- Each interval is two-sided Clopper–Pearson. Allocate 0.01/[(w+1)(w+2)] to zero-indexed wave w and divide equally among **all** its intervals, including normalization and descriptive scale masses. The sum over all waves is 0.01. Bonferroni permits dependence across fidelities. This covers the individual binomial probabilities assuming the specified samplers and ideal independent streams; numerical/modeling errors are outside its scope.
- Each Born interval must contain t and fit inside t ± 0.012. Each packet interval must contain its predicted value; the final corrected rate must also meet the ±0.012 precision budget. Geometry, normalization and mutant checks must pass. Smoke uses ±0.060. Increasing confidence at late waves can eventually make a panel inconclusive at fixed sample size.
- For each saved decoder the lower confidence limit for m must reach at least half of the ensemble benchmark. This is a prespecified strength threshold, not an identity required of all decoders. Finite-size lower bounds and their prefactors are reported even on a miss. The s-power in the formula is partly imposed by the chosen geometry; a fitted slope would not independently measure the critical exponent.
- A single scientific miss sets REVIEW and persists. Completion requires all 93 core cells. A time limit or interrupted extension may leave a partial extension; every completed extension cell also counts toward review. Partial core data give INCOMPLETE unless findings require REVIEW. Hardware or software exceptions terminate with a traceback, and the affected cell is replayed on relaunch. A finished smoke run is always labeled SMOKE ONLY. Finite success supports the tested implications, while release of a proof claim depends on a separate mathematical review.
