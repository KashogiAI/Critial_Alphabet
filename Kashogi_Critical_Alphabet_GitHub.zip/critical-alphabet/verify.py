"""Reproduce the deterministic checks and audit the released sample counts.

Use --full for a fresh CPU run and a comparison with every archived cell.
The default comparison is local and requires no GPU or downloaded data.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT / "reference"

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def check_files():
    manifest = ROOT / "SHA256SUMS"
    for line in manifest.read_text().splitlines():
        expected, name = line.split("  ", 1)
        if sha256(ROOT / name) != expected:
            raise ValueError(f"checksum mismatch: {name}")

def cells(directory):
    return {p.stem: load(p) for p in sorted((directory / "cells").glob("*.json"))}

def audit_panel(directory):
    from scipy.stats import binomtest
    import numpy as np
    quadrature = load(directory/"quadrature.json")
    assert len(quadrature["checks"]) == 15 and all(row["pass"] for row in quadrature["checks"])
    mixture = [row for row in quadrature["checks"] if "int K_s" in row["check"]]
    assert len(mixture)==1 and abs(mixture[0]["value"]) <= 2.38e-8
    data = cells(directory)
    expected = {(wave, "packets", 0, 0) for wave in range(3)}
    expected |= {(wave, "born", d, 0) for wave in range(3) for d in range(4,9)}
    expected |= {(wave, "witness", d, n) for wave in range(3)
                 for d in range(4,9) for n in (2,8,32,128,512)}
    assert len(data) == 93
    assert expected == {(r["wave"],r["kind"],r["d"],r.get("n",0)) for r in data.values()}
    answers = []
    by_dim = {d: [0, 0.0, []] for d in range(4,9)}
    anchors = bits = comparisons = packets = 0
    for r in data.values():
        if r["kind"] == "born":
            anchors += r["accepted"]
            by_dim[r["d"]][0] += r["accepted"]
            assert r["mass_ok"] and r["mutant_false_accepts"] > 0
            for h in r["responses"]:
                k,n,t = h["hits"],h["trials"],h["t"]
                lo,hi = binomtest(k,n).proportion_ci(1-r["alpha"],method="exact")
                assert np.allclose([lo,hi],[h["low"],h["high"]],rtol=0,atol=5e-10)
                assert lo <= t <= hi and max(t-lo,hi-t) <= r["tolerance"]
                error = abs(k/n-t)
                by_dim[r["d"]][1] = max(error, by_dim[r["d"]][1])
                answers.append((error,r["d"],t,k,n))
                bits += n
        elif r["kind"] == "witness":
            n,d,s,t = r["n"],r["d"],r["s"],r["t"]
            comparison = 2*n*r["trials"]
            assert comparison == r["tested_fidelities"]
            comparisons += comparison
            assert sha256(directory/"cells"/r["centres"]) == r["centres_sha256"]
            lo = binomtest(r["hits"],r["trials"]).proportion_ci(1-r["alpha"]).low
            assert lo >= r["ensemble_prediction"]/2
            for b in r["bounds"]:
                computed = n*s**(d-1)*(lo/t)**b["p"]
                assert np.isclose(computed,b["lower_bound"],rtol=2e-8,atol=0)
                if n==512 and b["p"]==d-1:
                    by_dim[d][2].append(computed)
        else:
            for h in r["cases"]:
                from math import comb
                pop,B,g = h["population"],h["unsafe"],h["size"]
                pg = comb(pop-1-B,g-1) / comb(pop-1,g-1)
                assert abs(pg-h["p_g"]) < 1e-14
                for k,target in [(h["accepted"],0.75),(h["all_safe"],pg)]:
                    lo,hi=binomtest(k,h["trials"]).proportion_ci(1-r["alpha"])
                    assert lo <= target <= hi
                assert h["target_inside"] and h["within_tolerance"]
                packets += h["trials"]
    assert (anchors,bits,comparisons,packets)==(6943070,62487630,2681733120,3145728)
    table = {4:(3146183,.00086744,.872750),5:(1834756,.00095795,.106409),
             6:(1046648,.00181094,.0126192),7:(588901,.00219489,.00155111),
             8:(326582,.00164808,.000185654)}
    for dim,(count,residual,witness) in table.items():
        actual_count,actual_residual,bounds=by_dim[dim]
        assert count == actual_count and abs(actual_residual-residual)<=5.1e-9
        assert len(bounds)==3 and np.isclose(min(bounds),witness,rtol=5.1e-6,atol=0)
    _,d,t,k,n=max(answers)
    assert (d,t,k,n)==(7,0.5,97638,196137)
    print(f"Panel verified: {len(data)} cells; {anchors:,} anchors; {bits:,} bits; "
          f"{comparisons:,} centre comparisons; {packets:,} packet trials.")
    print(f"Largest Born residual: {abs(k/n-t):.10f} (d={d}, target={t}, {k}/{n}).")

def run(*args,capture=False):
    env=dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1",
             MKL_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
    p=subprocess.run([sys.executable,*args],cwd=ROOT,env=env,text=True,check=True,
                     stdout=subprocess.PIPE if capture else None)
    return p.stdout

def verify(full):
    check_files()
    run("check_dimension.py")
    out=json.loads(run("check_povm_lift.py",capture=True))
    expected=load(REFERENCE/"povm_checks.json")
    for key in ("exact", "exact_theorem_scale"):
        assert out[key]==expected[key]
    for k in ("frames","fixed_tape_vectors"):
        assert out["stress"][k]==expected["stress"][k]
    print(json.dumps(out,indent=2))
    run("tests/test_core.py")
    run("tests/test_evidence.py")
    audit_panel(REFERENCE)
    if full:
        with tempfile.TemporaryDirectory(prefix="alphabet-replay-") as d:
            fresh=Path(d)/"run"
            run("-m","ququart_lab.campaign","--backend","numpy","--core-only",
                "--out",str(fresh))
            audit_panel(fresh)
            before,after=cells(REFERENCE),cells(fresh)
            for name in before:
                orig=dict(before[name]); current=dict(after[name])
                orig.pop("seconds"); current.pop("seconds")
                if orig != current:
                    raise ValueError(f"replay differs from the reference cell {name}; "
                                     "strict replay uses the pinned reference environment")
            print("Fresh CPU replay matched all 93 archived cells, excluding elapsed times.")
    print("PASS")

if __name__=="__main__":
    if not __debug__:
        sys.exit("Assertions must be enabled. Run without -O and unset PYTHONOPTIMIZE.")
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--full", action="store_true", help="regenerate all 93 CPU cells")
    verify(ap.parse_args().full)
